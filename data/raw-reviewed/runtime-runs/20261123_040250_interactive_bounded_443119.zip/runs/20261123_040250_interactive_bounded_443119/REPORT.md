# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_040250_interactive_bounded_443119",
  "active_seconds": 39.86012996600002,
  "published_frames": 1993,
  "debug_samples": 1993,
  "physics_samples": 1993,
  "fall_count": 0,
  "publish_hz": 50.00042311101014,
  "debug_hz": 49.99898433288102,
  "realtime_factor": 0.9999881743610289,
  "spring_disabled": true,
  "base_height_min_m": 0.7539268734452278,
  "base_height_max_m": 0.7781885494328775,
  "actual_base_displacement_m": 0.006734468613218701,
  "actual_base_path_length_m": 0.24923744271636153,
  "tracking_rmse_rad": 0.13520781781083221,
  "left_arm_tracking_rmse_rad": 0.19140140103752687,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.0894376023032014e-08,
    "p95": 1.4483228963146119e-08,
    "max": 1.720338357639795e-08
  },
  "target_observation_lag_ms": {
    "p50": 64.75163099999293,
    "p95": 69.08017694999415,
    "max": 109.46942499998613
  },
  "max_reference_edit_rad": 1.0547287802935976,
  "left_shoulder_actual_range_rad": 0.28134173154830927,
  "left_arm_reference_speed_max_rad_s": 0.2967854953734358,
  "left_arm_reference_accel_max_rad_s2": 8.041304806962762,
  "intervention_selected_speed_max_rad_s": 0.6120534044488569,
  "intervention_selected_accel_max_rad_s2": 8.191899653673302,
  "edit_compute_ms": {
    "p50": 2.035258000006479,
    "p95": 3.694804999997814,
    "max": 9.326326000007157
  },
  "physics_sample_gap_ms": {
    "p50": 20.003240000008304,
    "p95": 20.933812799999885,
    "max": 59.74467800001548
  },
  "feedback_sample_gap_ms": {
    "p50": 19.973140999994143,
    "p95": 24.641837250004524,
    "max": 31.80987399997548
  },
  "publish_interval_ms": {
    "p50": 19.999777499990046,
    "p95": 20.064066549998927,
    "max": 47.67254999998727
  },
  "scheduling_lateness_ms": {
    "p50": 0.08704598016606724,
    "p95": 0.15864898327322394,
    "max": 27.74488299633049
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.788,
      "p95": 5.0486,
      "max": 5.494
    },
    "policy": {
      "p50": 3.671,
      "p95": 3.8204000000000002,
      "max": 3.866
    },
    "observation_to_motor": {
      "p50": 8.428,
      "p95": 8.6756,
      "max": 8.904
    }
  },
  "http_command_queue_ms": {
    "p50": 2.0019380000064757,
    "p95": 17.695622600012936,
    "max": 19.364713000015854
  },
  "http_to_reference_publish_ms": {
    "p50": 5.460537999994131,
    "p95": 20.573057599995078,
    "max": 24.33509799999456
  },
  "takeover_seams": [
    {
      "t": 149.023866187,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.32421875,
      "controller": 345.77734375,
      "publisher": 125.15234375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1888.35546875,
    "min_wsl_available_mib": 5610.98046875,
    "nvml_gpu_peak_mib": 1326,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
