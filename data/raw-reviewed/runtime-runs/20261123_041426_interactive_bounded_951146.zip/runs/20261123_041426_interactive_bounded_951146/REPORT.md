# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_041426_interactive_bounded_951146",
  "active_seconds": 39.84012662699999,
  "published_frames": 1992,
  "debug_samples": 1993,
  "physics_samples": 1992,
  "fall_count": 0,
  "publish_hz": 50.000184801034614,
  "debug_hz": 50.00218666942145,
  "realtime_factor": 0.9999473724078654,
  "spring_disabled": true,
  "base_height_min_m": 0.7529857965472259,
  "base_height_max_m": 0.7773649411277863,
  "actual_base_displacement_m": 0.003411777495895354,
  "actual_base_path_length_m": 0.25624370069635405,
  "tracking_rmse_rad": 0.1356072426513557,
  "left_arm_tracking_rmse_rad": 0.19274520355174915,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.0906849997915819e-08,
    "p95": 1.4300910910300852e-08,
    "max": 1.7581390811943342e-08
  },
  "target_observation_lag_ms": {
    "p50": 100.80180250000126,
    "p95": 104.9176703999933,
    "max": 162.25894199999402
  },
  "max_reference_edit_rad": 1.0552303691327731,
  "left_shoulder_actual_range_rad": 0.28533858060836786,
  "left_arm_reference_speed_max_rad_s": 0.38383122147174026,
  "left_arm_reference_accel_max_rad_s2": 7.500000000000272,
  "intervention_selected_speed_max_rad_s": 0.7837184485458717,
  "intervention_selected_accel_max_rad_s2": 7.500000000000755,
  "edit_compute_ms": {
    "p50": 2.4153024999975514,
    "p95": 3.417352349991631,
    "max": 6.351254999998446
  },
  "physics_sample_gap_ms": {
    "p50": 19.97607399999879,
    "p95": 21.066853999997193,
    "max": 89.82554600001436
  },
  "feedback_sample_gap_ms": {
    "p50": 20.01976350000234,
    "p95": 21.903303400003438,
    "max": 30.701187999994772
  },
  "publish_interval_ms": {
    "p50": 20.00041200000169,
    "p95": 20.07241049999209,
    "max": 70.71278399999414
  },
  "scheduling_lateness_ms": {
    "p50": 0.10109549104697635,
    "p95": 0.177011297256513,
    "max": 50.86266999711597
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.7645,
      "p95": 5.6694499999999985,
      "max": 6.771
    },
    "policy": {
      "p50": 3.674,
      "p95": 3.82725,
      "max": 3.854
    },
    "observation_to_motor": {
      "p50": 8.414,
      "p95": 9.333399999999997,
      "max": 10.4
    }
  },
  "http_command_queue_ms": {
    "p50": 7.692611499990676,
    "p95": 17.245555000002355,
    "max": 19.70624500000895
  },
  "http_to_reference_publish_ms": {
    "p50": 10.819203499991659,
    "p95": 20.43751800000848,
    "max": 23.412668000020176
  },
  "takeover_seams": [
    {
      "t": 134.270447202,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1421.93359375,
      "controller": 344.99609375,
      "publisher": 112.609375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1875.12890625,
    "min_wsl_available_mib": 5616.9765625,
    "nvml_gpu_peak_mib": 1331,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
