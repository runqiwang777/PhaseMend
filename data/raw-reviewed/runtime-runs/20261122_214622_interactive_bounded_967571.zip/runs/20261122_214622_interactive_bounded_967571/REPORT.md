# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261122_214622_interactive_bounded_967571",
  "active_seconds": 16.080138927000007,
  "published_frames": 804,
  "debug_samples": 804,
  "physics_samples": 804,
  "fall_count": 0,
  "publish_hz": 50.000689670160355,
  "debug_hz": 49.98490982961236,
  "realtime_factor": 0.9999915110930517,
  "spring_disabled": true,
  "base_height_min_m": 0.7592670862164459,
  "base_height_max_m": 0.7771406091680142,
  "actual_base_displacement_m": 0.008522261355052175,
  "actual_base_path_length_m": 0.14553586312901984,
  "tracking_rmse_rad": 0.13577981578444212,
  "left_arm_tracking_rmse_rad": 0.17702611751641292,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2142566845443758e-08,
    "p95": 1.503793790634843e-08,
    "max": 0.0004870276545082784
  },
  "target_observation_lag_ms": {
    "p50": 72.97198600001309,
    "p95": 75.60855735001013,
    "max": 114.20638300000974
  },
  "max_reference_edit_rad": 0.9100359243975709,
  "left_shoulder_actual_range_rad": 0.07867306470870972,
  "left_arm_reference_speed_max_rad_s": 0.41419331599660825,
  "left_arm_reference_accel_max_rad_s2": 7.999999999999951,
  "intervention_selected_speed_max_rad_s": 1.3474188121278097,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 1.9412555000002385,
    "p95": 3.3188471000002533,
    "max": 7.462481999993997
  },
  "physics_sample_gap_ms": {
    "p50": 19.992908999995507,
    "p95": 20.849305399994478,
    "max": 49.553561000010404
  },
  "feedback_sample_gap_ms": {
    "p50": 19.970424999996794,
    "p95": 22.909214500003827,
    "max": 27.84178699999984
  },
  "publish_interval_ms": {
    "p50": 20.0007120000123,
    "p95": 20.086046200015062,
    "max": 29.624197999993385
  },
  "scheduling_lateness_ms": {
    "p50": 0.09540899667115355,
    "p95": 0.18804799450009466,
    "max": 9.761086996547874
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 5.253,
      "p95": 5.6315,
      "max": 5.661
    },
    "policy": {
      "p50": 4.1085,
      "p95": 4.31725,
      "max": 4.707
    },
    "observation_to_motor": {
      "p50": 9.424,
      "p95": 9.89125,
      "max": 10.273
    }
  },
  "http_command_queue_ms": {
    "p50": 9.113795000018854,
    "p95": 17.10326140001257,
    "max": 19.382554000003438
  },
  "http_to_reference_publish_ms": {
    "p50": 11.940834999990102,
    "p95": 20.656874200005856,
    "max": 24.349291000021367
  },
  "takeover_seams": [
    {
      "t": 146.242849598,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1424.1953125,
      "controller": 342.54296875,
      "publisher": 116.83984375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1879.671875,
    "min_wsl_available_mib": 5619.640625,
    "nvml_gpu_peak_mib": 1524,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
