# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "failed",
  "error": "No fresh SONIC feedback for >1 second",
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_232202_interactive_bounded_156541",
  "active_seconds": 86.83177647000002,
  "published_frames": 4298,
  "debug_samples": 4291,
  "physics_samples": 1995,
  "fall_count": 0,
  "publish_hz": 49.489505520954246,
  "debug_hz": 49.99840512138719,
  "realtime_factor": 0.45952838471347024,
  "spring_disabled": true,
  "base_height_min_m": 0.7688827080899734,
  "base_height_max_m": 0.7763949350087391,
  "actual_base_displacement_m": 0.0982294301152826,
  "actual_base_path_length_m": 0.10652881207205449,
  "tracking_rmse_rad": 0.415398764126071,
  "left_arm_tracking_rmse_rad": 0.15157402441833345,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2400873687409261e-08,
    "p95": 1.572932875645856e-08,
    "max": 1.8952723637132984e-08
  },
  "target_observation_lag_ms": {
    "p50": 66.38203250003016,
    "p95": 87.65013355008477,
    "max": 93.03596300003392
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.0049183666706085205,
  "left_arm_reference_speed_max_rad_s": 0.330976423700014,
  "left_arm_reference_accel_max_rad_s2": 73.34602496338134,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7671679999816661,
    "p95": 1.0199806999878538,
    "max": 61.33579599998029
  },
  "physics_sample_gap_ms": {
    "p50": 40.39696249998315,
    "p95": 96.05543779994146,
    "max": 173.5340630000337
  },
  "feedback_sample_gap_ms": {
    "p50": 19.930882999972255,
    "p95": 39.32903935001377,
    "max": 47.270510999965154
  },
  "publish_interval_ms": {
    "p50": 20.00074600005064,
    "p95": 20.094659000005777,
    "max": 64.27516100006869
  },
  "scheduling_lateness_ms": {
    "p50": 0.09964352938141019,
    "p95": 0.20114174009790975,
    "max": 127.6731830001836
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.786,
      "p95": 4.943,
      "max": 5.288
    },
    "policy": {
      "p50": 3.68,
      "p95": 3.845,
      "max": 4.032
    },
    "observation_to_motor": {
      "p50": 8.466,
      "p95": 8.713,
      "max": 9.014
    }
  },
  "checks": {
    "no_runtime_error": false,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1440.421875,
      "controller": 350.94140625,
      "publisher": 95.8125,
      "viewer": 0
    },
    "max_sum_rss_mib": 1876.1328125,
    "min_wsl_available_mib": 5599.84375,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
