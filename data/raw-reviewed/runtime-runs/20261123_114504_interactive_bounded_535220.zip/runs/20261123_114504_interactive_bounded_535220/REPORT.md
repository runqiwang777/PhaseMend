# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_114504_interactive_bounded_535220",
  "active_seconds": 16.193390616999977,
  "published_frames": 794,
  "debug_samples": 809,
  "physics_samples": 419,
  "fall_count": 0,
  "publish_hz": 49.03223200010411,
  "debug_hz": 50.005733723649186,
  "realtime_factor": 0.5183322030393406,
  "spring_disabled": true,
  "base_height_min_m": 0.7498682509703317,
  "base_height_max_m": 0.7728534069217988,
  "actual_base_displacement_m": 0.10750152906350581,
  "actual_base_path_length_m": 0.3049141245727369,
  "tracking_rmse_rad": 0.148444909161649,
  "left_arm_tracking_rmse_rad": 0.1539273041930859,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2321335464668698e-08,
    "p95": 1.5409548810943698e-08,
    "max": 1.799257981066085e-08
  },
  "target_observation_lag_ms": {
    "p50": 41.17405499999904,
    "p95": 45.365633000011485,
    "max": 46.693917999988344
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.09902839362621307,
  "left_arm_reference_speed_max_rad_s": 0.15524289222310086,
  "left_arm_reference_accel_max_rad_s2": 4.2982002478629555,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7179939999986118,
    "p95": 20.55673224999168,
    "max": 35.0916050000194
  },
  "physics_sample_gap_ms": {
    "p50": 37.72146799998666,
    "p95": 76.1569168499946,
    "max": 118.75243099999011
  },
  "feedback_sample_gap_ms": {
    "p50": 20.063612000001285,
    "p95": 22.928024100008315,
    "max": 27.44621999997321
  },
  "publish_interval_ms": {
    "p50": 20.005165000014813,
    "p95": 23.080768599999146,
    "max": 38.78082500000346
  },
  "scheduling_lateness_ms": {
    "p50": 0.1041974949202995,
    "p95": 55.41782024980202,
    "max": 112.1650589996932
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 5.509,
      "p95": 5.795,
      "max": 5.808
    },
    "policy": {
      "p50": 4.505,
      "p95": 4.6489,
      "max": 4.805
    },
    "observation_to_motor": {
      "p50": 10.059,
      "p95": 10.4192,
      "max": 10.459
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1440.8984375,
      "controller": 340.6953125,
      "publisher": 94.09375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1868.34375,
    "min_wsl_available_mib": 5627.70703125,
    "nvml_gpu_peak_mib": 1510,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
