# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_233741_interactive_bounded_680378",
  "active_seconds": 146.161967596,
  "published_frames": 7287,
  "debug_samples": 7308,
  "physics_samples": 3165,
  "fall_count": 0,
  "publish_hz": 49.85587416055263,
  "debug_hz": 49.999487085116634,
  "realtime_factor": 0.43311561135160287,
  "spring_disabled": true,
  "base_height_min_m": 0.768715313430468,
  "base_height_max_m": 0.7766813822785,
  "actual_base_displacement_m": 0.08713746334623657,
  "actual_base_path_length_m": 0.09426996678634991,
  "tracking_rmse_rad": 0.43204602700033146,
  "left_arm_tracking_rmse_rad": 0.14177928956410507,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2400873687409261e-08,
    "p95": 1.4914872615984287e-08,
    "max": 1.8952723637132984e-08
  },
  "target_observation_lag_ms": {
    "p50": 140.07359450000934,
    "p95": 140.86254630000354,
    "max": 150.2673310000091
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.004856333136558533,
  "left_arm_reference_speed_max_rad_s": 1.1871903128403383,
  "left_arm_reference_accel_max_rad_s2": 272.87953916268964,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.9849460000168619,
    "p95": 1.4051503999638724,
    "max": 44.64267000000177
  },
  "physics_sample_gap_ms": {
    "p50": 41.58756900000071,
    "p95": 93.43219595001813,
    "max": 187.66082700000197
  },
  "feedback_sample_gap_ms": {
    "p50": 19.994412000016837,
    "p95": 21.020414800003095,
    "max": 29.891184999996767
  },
  "publish_interval_ms": {
    "p50": 20.00029249998647,
    "p95": 20.155694499983667,
    "max": 47.498993999994354
  },
  "scheduling_lateness_ms": {
    "p50": 0.09819495221563557,
    "p95": 0.25670617783362104,
    "max": 110.81233399974622
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.829000000000001,
      "p95": 5.0488,
      "max": 5.522
    },
    "policy": {
      "p50": 3.678,
      "p95": 3.8576,
      "max": 4.062
    },
    "observation_to_motor": {
      "p50": 8.4875,
      "p95": 8.79635,
      "max": 9.305
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.52734375,
      "controller": 357.44921875,
      "publisher": 95.25,
      "viewer": 0
    },
    "max_sum_rss_mib": 1894.2265625,
    "min_wsl_available_mib": 5594.08203125,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
