# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_233027_interactive_bounded_183628",
  "active_seconds": 146.170277763,
  "published_frames": 7264,
  "debug_samples": 7308,
  "physics_samples": 2989,
  "fall_count": 0,
  "publish_hz": 49.695732656806705,
  "debug_hz": 49.99985766668409,
  "realtime_factor": 0.4091177830935891,
  "spring_disabled": true,
  "base_height_min_m": 0.7715704859869779,
  "base_height_max_m": 0.7760019653764746,
  "actual_base_displacement_m": 0.07173854605717393,
  "actual_base_path_length_m": 0.07896702461684665,
  "tracking_rmse_rad": 0.42468686620006996,
  "left_arm_tracking_rmse_rad": 0.15657635960792954,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2400873687409261e-08,
    "p95": 1.4914872615984287e-08,
    "max": 1.8952723637132984e-08
  },
  "target_observation_lag_ms": {
    "p50": 186.7154494999994,
    "p95": 187.57301059999492,
    "max": 197.54045399997722
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.005278930068016052,
  "left_arm_reference_speed_max_rad_s": 0.5182037875845071,
  "left_arm_reference_accel_max_rad_s2": 140.153736204575,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7519235000046365,
    "p95": 0.9147160000068764,
    "max": 53.786946000002445
  },
  "physics_sample_gap_ms": {
    "p50": 42.528681000007396,
    "p95": 99.37055530000126,
    "max": 166.51082600000677
  },
  "feedback_sample_gap_ms": {
    "p50": 19.999662000003582,
    "p95": 21.073335300010854,
    "max": 36.16962300000637
  },
  "publish_interval_ms": {
    "p50": 20.00019100000827,
    "p95": 20.063846599981616,
    "max": 58.30652399998826
  },
  "scheduling_lateness_ms": {
    "p50": 0.09271597619431304,
    "p95": 0.15834118901523198,
    "max": 119.29958799990459
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.7765,
      "p95": 4.9072,
      "max": 5.021
    },
    "policy": {
      "p50": 3.7145,
      "p95": 3.92705,
      "max": 6.27
    },
    "observation_to_motor": {
      "p50": 8.4835,
      "p95": 8.81685,
      "max": 11.208
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1442.01171875,
      "controller": 357.45703125,
      "publisher": 100.68359375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1885.94140625,
    "min_wsl_available_mib": 5603.4609375,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
