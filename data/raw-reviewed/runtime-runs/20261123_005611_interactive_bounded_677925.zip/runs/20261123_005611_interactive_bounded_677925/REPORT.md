# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_005611_interactive_bounded_677925",
  "active_seconds": 11.740117529999907,
  "published_frames": 587,
  "debug_samples": 587,
  "physics_samples": 587,
  "fall_count": 0,
  "publish_hz": 50.00127190522109,
  "debug_hz": 49.98530868656335,
  "realtime_factor": 0.9999513829103198,
  "spring_disabled": true,
  "base_height_min_m": 0.7597134520704452,
  "base_height_max_m": 0.7764297417378158,
  "actual_base_displacement_m": 0.0032566429897108785,
  "actual_base_path_length_m": 0.10142381071628367,
  "tracking_rmse_rad": 0.11822384044332458,
  "left_arm_tracking_rmse_rad": 0.16657188472862208,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.276246549973496e-08,
    "p95": 1.5563502436309526e-08,
    "max": 1.7361380778046492e-08
  },
  "target_observation_lag_ms": {
    "p50": 96.38824499995735,
    "p95": 100.58290984999303,
    "max": 117.82751100008682
  },
  "max_reference_edit_rad": 0.642637996300229,
  "left_shoulder_actual_range_rad": 0.1187936663627624,
  "left_arm_reference_speed_max_rad_s": 0.4053033574047682,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000023,
  "intervention_selected_speed_max_rad_s": 1.0042728913162164,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 1.8920879999768658,
    "p95": 3.62502679998897,
    "max": 4.680093000047236
  },
  "physics_sample_gap_ms": {
    "p50": 20.00188450006135,
    "p95": 20.80621924997672,
    "max": 53.70190700000421
  },
  "feedback_sample_gap_ms": {
    "p50": 20.00684000000774,
    "p95": 23.861796250002953,
    "max": 35.915336000016396
  },
  "publish_interval_ms": {
    "p50": 20.000174500012236,
    "p95": 20.05084999998985,
    "max": 41.473860999985845
  },
  "scheduling_lateness_ms": {
    "p50": 0.07728500895609614,
    "p95": 0.13652450815015976,
    "max": 21.548551003093053
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.76,
      "p95": 4.9350000000000005,
      "max": 4.984
    },
    "policy": {
      "p50": 3.723,
      "p95": 3.8520000000000003,
      "max": 3.877
    },
    "observation_to_motor": {
      "p50": 8.472,
      "p95": 8.74,
      "max": 8.744
    }
  },
  "http_command_queue_ms": {
    "p50": 7.119289000002027,
    "p95": 18.231338700024935,
    "max": 19.970141999920088
  },
  "http_to_reference_publish_ms": {
    "p50": 10.314624499983438,
    "p95": 21.296121349990923,
    "max": 26.934664000009434
  },
  "takeover_seams": [
    {
      "t": 563.460670481,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.09375,
      "controller": 341.71875,
      "publisher": 126.109375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1889.515625,
    "min_wsl_available_mib": 5605.0703125,
    "nvml_gpu_peak_mib": 1290,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
