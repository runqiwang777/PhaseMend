# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_215347_interactive_bounded_834747",
  "active_seconds": 32.43620211300001,
  "published_frames": 1600,
  "debug_samples": 1622,
  "physics_samples": 724,
  "fall_count": 0,
  "publish_hz": 49.3278983857771,
  "debug_hz": 50.00101547096248,
  "realtime_factor": 0.4469195363353247,
  "spring_disabled": true,
  "base_height_min_m": 0.7656753812286439,
  "base_height_max_m": 0.7771797426607328,
  "actual_base_displacement_m": 0.12284434316148349,
  "actual_base_path_length_m": 0.33169302208068935,
  "tracking_rmse_rad": 0.23472234479119117,
  "left_arm_tracking_rmse_rad": 0.19404682110493274,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.3030053548264838e-08,
    "p95": 1.6601320425593395e-08,
    "max": 1.8865082788042668e-08
  },
  "target_observation_lag_ms": {
    "p50": 272.2339290000093,
    "p95": 273.64354780000326,
    "max": 290.52753600001324
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.076587975025177,
  "left_arm_reference_speed_max_rad_s": 0.23744312764782105,
  "left_arm_reference_accel_max_rad_s2": 44.24493190188659,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7320444999976417,
    "p95": 2.522730800005486,
    "max": 58.33074599999577
  },
  "physics_sample_gap_ms": {
    "p50": 39.12233299999457,
    "p95": 108.90991380001081,
    "max": 191.77180599999133
  },
  "feedback_sample_gap_ms": {
    "p50": 19.983737999979212,
    "p95": 21.213091000021222,
    "max": 36.049742000017204
  },
  "publish_interval_ms": {
    "p50": 20.001188999998476,
    "p95": 21.00796180001225,
    "max": 60.857394999999315
  },
  "scheduling_lateness_ms": {
    "p50": 0.10948399381049967,
    "p95": 9.315115993000207,
    "max": 119.51692299990668
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.708,
      "p95": 4.8496,
      "max": 5.194
    },
    "policy": {
      "p50": 3.673,
      "p95": 3.8829999999999996,
      "max": 3.943
    },
    "observation_to_motor": {
      "p50": 8.435,
      "p95": 8.6204,
      "max": 8.786
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.2578125,
      "controller": 343.40625,
      "publisher": 99.35546875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1874.33203125,
    "min_wsl_available_mib": 5619.43359375,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
