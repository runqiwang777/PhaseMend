# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_113838_interactive_bounded_925329",
  "active_seconds": 17.89298244699998,
  "published_frames": 868,
  "debug_samples": 895,
  "physics_samples": 413,
  "fall_count": 0,
  "publish_hz": 48.5105232616111,
  "debug_hz": 49.999882791102415,
  "realtime_factor": 0.46132345789965234,
  "spring_disabled": true,
  "base_height_min_m": 0.7502693468925089,
  "base_height_max_m": 0.7740032093513551,
  "actual_base_displacement_m": 0.10652866568795537,
  "actual_base_path_length_m": 0.29498404150702534,
  "tracking_rmse_rad": 0.14547214788381027,
  "left_arm_tracking_rmse_rad": 0.15296320661707585,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2483937326935454e-08,
    "p95": 1.5511210437004017e-08,
    "max": 1.9543261923437793e-08
  },
  "target_observation_lag_ms": {
    "p50": 239.41879899999208,
    "p95": 241.12718520001408,
    "max": 245.5543030000058
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.1493526697158813,
  "left_arm_reference_speed_max_rad_s": 0.15580695226638427,
  "left_arm_reference_accel_max_rad_s2": 4.298589794067357,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7686820000145644,
    "p95": 21.273037850006915,
    "max": 42.89104299999735
  },
  "physics_sample_gap_ms": {
    "p50": 39.80419799999879,
    "p95": 92.6878023499981,
    "max": 165.70322299997997
  },
  "feedback_sample_gap_ms": {
    "p50": 20.022423000000344,
    "p95": 21.770469950014615,
    "max": 28.0994330000226
  },
  "publish_interval_ms": {
    "p50": 20.00336700001526,
    "p95": 24.156415699999886,
    "max": 47.101023999999825
  },
  "scheduling_lateness_ms": {
    "p50": 0.10409399730804125,
    "p95": 43.75598409992989,
    "max": 115.32357399988769
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.4254999999999995,
      "p95": 4.5651,
      "max": 4.682
    },
    "policy": {
      "p50": 4.5600000000000005,
      "p95": 4.7985,
      "max": 4.818
    },
    "observation_to_motor": {
      "p50": 9.014,
      "p95": 9.33705,
      "max": 9.371
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1440.55078125,
      "controller": 341.4453125,
      "publisher": 107.15234375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1881.8046875,
    "min_wsl_available_mib": 5617.984375,
    "nvml_gpu_peak_mib": 1510,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
