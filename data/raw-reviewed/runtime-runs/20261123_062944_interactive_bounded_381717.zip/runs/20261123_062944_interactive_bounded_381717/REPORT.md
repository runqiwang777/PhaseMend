# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_062944_interactive_bounded_381717",
  "active_seconds": 38.12344548000004,
  "published_frames": 1874,
  "debug_samples": 1906,
  "physics_samples": 1906,
  "fall_count": 0,
  "publish_hz": 49.15618978409313,
  "debug_hz": 49.99962222988834,
  "realtime_factor": 0.9999936871262067,
  "spring_disabled": true,
  "base_height_min_m": 0.7429315251298838,
  "base_height_max_m": 0.7759297557445746,
  "actual_base_displacement_m": 0.03166135372663486,
  "actual_base_path_length_m": 0.3485348317482473,
  "tracking_rmse_rad": 0.214451912126046,
  "left_arm_tracking_rmse_rad": 0.24296341129932622,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2792790192986389e-08,
    "p95": 1.648690730512624e-08,
    "max": 1.9324860165334827e-08
  },
  "target_observation_lag_ms": {
    "p50": 111.41055399997413,
    "p95": 112.22835500000201,
    "max": 117.37916699996731
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.24603257607668638,
  "left_arm_reference_speed_max_rad_s": 0.25732760861804715,
  "left_arm_reference_accel_max_rad_s2": 57.87406075567863,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.707816000016237,
    "p95": 1.3309637500100227,
    "max": 41.32200899999816
  },
  "physics_sample_gap_ms": {
    "p50": 19.985639000026367,
    "p95": 20.843337400003747,
    "max": 62.6468579999937
  },
  "feedback_sample_gap_ms": {
    "p50": 20.009417999972356,
    "p95": 20.95807439999362,
    "max": 25.27005599995391
  },
  "publish_interval_ms": {
    "p50": 20.000294999988455,
    "p95": 20.11170700002367,
    "max": 43.685202999995454
  },
  "scheduling_lateness_ms": {
    "p50": 0.07631351300574352,
    "p95": 0.2071101698106751,
    "max": 121.74621600013324
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.732,
      "p95": 4.933,
      "max": 5.18
    },
    "policy": {
      "p50": 3.726,
      "p95": 3.839,
      "max": 3.88
    },
    "observation_to_motor": {
      "p50": 8.459,
      "p95": 8.7185,
      "max": 8.95
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1425.109375,
      "controller": 344.17578125,
      "publisher": 104.51953125,
      "viewer": 0
    },
    "max_sum_rss_mib": 1868.6484375,
    "min_wsl_available_mib": 5620.6328125,
    "nvml_gpu_peak_mib": 1331,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
