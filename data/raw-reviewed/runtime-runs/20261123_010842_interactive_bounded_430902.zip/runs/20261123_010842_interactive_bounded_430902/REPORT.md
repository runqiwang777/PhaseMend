# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_010842_interactive_bounded_430902",
  "active_seconds": 17.460134780999994,
  "published_frames": 873,
  "debug_samples": 873,
  "physics_samples": 873,
  "fall_count": 0,
  "publish_hz": 50.00101410313648,
  "debug_hz": 49.992727872624116,
  "realtime_factor": 1.0000172468575939,
  "spring_disabled": true,
  "base_height_min_m": 0.7605028345579282,
  "base_height_max_m": 0.7771466642204732,
  "actual_base_displacement_m": 0.0024942102385474684,
  "actual_base_path_length_m": 0.1416735630301325,
  "tracking_rmse_rad": 0.1255010016127868,
  "left_arm_tracking_rmse_rad": 0.17212866790002998,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2158490812713208e-08,
    "p95": 1.558680459567439e-08,
    "max": 1.7629080657774547e-08
  },
  "target_observation_lag_ms": {
    "p50": 50.84541499999773,
    "p95": 72.7978184000051,
    "max": 110.71066199997404
  },
  "max_reference_edit_rad": 0.7691043903785261,
  "left_shoulder_actual_range_rad": 0.13420596718788141,
  "left_arm_reference_speed_max_rad_s": 0.3815855692466452,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000023,
  "intervention_selected_speed_max_rad_s": 1.0377225112523778,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 1.9452860000228611,
    "p95": 3.328043800001977,
    "max": 7.4658289999831595
  },
  "physics_sample_gap_ms": {
    "p50": 20.00947000000508,
    "p95": 21.079503449992387,
    "max": 66.724808999993
  },
  "feedback_sample_gap_ms": {
    "p50": 19.975200499999346,
    "p95": 22.060680049982295,
    "max": 25.83810799998787
  },
  "publish_interval_ms": {
    "p50": 19.999431499996945,
    "p95": 20.061353299996654,
    "max": 62.89267399998266
  },
  "scheduling_lateness_ms": {
    "p50": 0.110195998644258,
    "p95": 0.161376994475404,
    "max": 43.021993993875185
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.747,
      "p95": 4.8618,
      "max": 4.908
    },
    "policy": {
      "p50": 3.749,
      "p95": 3.8366,
      "max": 3.873
    },
    "observation_to_motor": {
      "p50": 8.482,
      "p95": 8.672600000000001,
      "max": 8.709
    }
  },
  "http_command_queue_ms": {
    "p50": 10.434079999981805,
    "p95": 17.445090600000412,
    "max": 46.47946999997998
  },
  "http_to_reference_publish_ms": {
    "p50": 13.151286999999456,
    "p95": 20.925683199999412,
    "max": 49.053573999998434
  },
  "takeover_seams": [
    {
      "t": 152.577450132,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1421.796875,
      "controller": 342.28125,
      "publisher": 111.85546875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1873.92578125,
    "min_wsl_available_mib": 5625.79296875,
    "nvml_gpu_peak_mib": 1290,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
