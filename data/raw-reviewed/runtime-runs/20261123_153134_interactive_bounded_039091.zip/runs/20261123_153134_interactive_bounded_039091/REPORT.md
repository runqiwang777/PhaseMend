# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_153134_interactive_bounded_039091",
  "active_seconds": 24.57064158800003,
  "published_frames": 1191,
  "debug_samples": 1229,
  "physics_samples": 448,
  "fall_count": 0,
  "publish_hz": 48.472496299469434,
  "debug_hz": 49.99960805274673,
  "realtime_factor": 0.3642880875311083,
  "spring_disabled": true,
  "base_height_min_m": 0.7237929694653379,
  "base_height_max_m": 0.7756356471051795,
  "actual_base_displacement_m": 0.17834517216172413,
  "actual_base_path_length_m": 0.4594199655588872,
  "tracking_rmse_rad": 0.16050502287740406,
  "left_arm_tracking_rmse_rad": 0.16733105897770012,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2920538600860915e-08,
    "p95": 1.6291334278320522e-08,
    "max": 1.8859122114888925e-08
  },
  "target_observation_lag_ms": {
    "p50": 230.90133200001617,
    "p95": 232.28944634999777,
    "max": 245.50440799998796
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.17990475893020624,
  "left_arm_reference_speed_max_rad_s": 1.329461227621811,
  "left_arm_reference_accel_max_rad_s2": 358.6436224875684,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7275409999749627,
    "p95": 21.10826150001799,
    "max": 39.29319699997791
  },
  "physics_sample_gap_ms": {
    "p50": 46.87132699999097,
    "p95": 110.6598959999985,
    "max": 170.43063299999517
  },
  "feedback_sample_gap_ms": {
    "p50": 20.008736999997723,
    "p95": 21.350426400030642,
    "max": 33.858361999989484
  },
  "publish_interval_ms": {
    "p50": 20.003220500015573,
    "p95": 25.21256754999967,
    "max": 43.62863099999004
  },
  "scheduling_lateness_ms": {
    "p50": 0.11627499515043382,
    "p95": 16.52097899993521,
    "max": 118.58603299990023
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.811,
      "p95": 5.2838,
      "max": 5.486
    },
    "policy": {
      "p50": 3.674,
      "p95": 3.9915000000000003,
      "max": 4.293
    },
    "observation_to_motor": {
      "p50": 8.489,
      "p95": 9.252500000000001,
      "max": 9.639
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.42578125,
      "controller": 342.37109375,
      "publisher": 105.21875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1880.421875,
    "min_wsl_available_mib": 5604.078125,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
