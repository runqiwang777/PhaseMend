# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_030621_interactive_bounded_111836",
  "active_seconds": 39.66031219200002,
  "published_frames": 1983,
  "debug_samples": 1983,
  "physics_samples": 1983,
  "fall_count": 0,
  "publish_hz": 50.000270386174584,
  "debug_hz": 49.998735444444975,
  "realtime_factor": 0.999995670275374,
  "spring_disabled": true,
  "base_height_min_m": 0.759701063870732,
  "base_height_max_m": 0.7788304923429049,
  "actual_base_displacement_m": 0.004822042244257704,
  "actual_base_path_length_m": 0.22739245318683163,
  "tracking_rmse_rad": 0.11921423395760042,
  "left_arm_tracking_rmse_rad": 0.1693705052625886,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2207682941079686e-08,
    "p95": 1.5941993977317377e-08,
    "max": 1.8353908867427728e-08
  },
  "target_observation_lag_ms": {
    "p50": 179.55237600000373,
    "p95": 182.7972184999993,
    "max": 219.505665000014
  },
  "max_reference_edit_rad": 0.9466852189383524,
  "left_shoulder_actual_range_rad": 0.22638367861509318,
  "left_arm_reference_speed_max_rad_s": 0.1611095499593327,
  "left_arm_reference_accel_max_rad_s2": 8.019773045815523,
  "intervention_selected_speed_max_rad_s": 0.9868070858157492,
  "intervention_selected_accel_max_rad_s2": 10.321670015143063,
  "edit_compute_ms": {
    "p50": 2.0824150000180452,
    "p95": 3.302870500013455,
    "max": 6.608626000002005
  },
  "physics_sample_gap_ms": {
    "p50": 20.000277499988783,
    "p95": 20.815630750001898,
    "max": 65.7603189999918
  },
  "feedback_sample_gap_ms": {
    "p50": 20.020664499995178,
    "p95": 22.39952194998977,
    "max": 30.291298000008737
  },
  "publish_interval_ms": {
    "p50": 19.999616999982095,
    "p95": 20.097873000000277,
    "max": 43.7011909999967
  },
  "scheduling_lateness_ms": {
    "p50": 0.08000699077115314,
    "p95": 0.19255188718716446,
    "max": 23.776271993654063
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.747,
      "p95": 4.95415,
      "max": 5.108
    },
    "policy": {
      "p50": 3.6985,
      "p95": 3.8577500000000002,
      "max": 3.895
    },
    "observation_to_motor": {
      "p50": 8.4635,
      "p95": 8.73535,
      "max": 8.822
    }
  },
  "http_command_queue_ms": {
    "p50": 9.059041000000434,
    "p95": 17.332676400002356,
    "max": 19.60160599998062
  },
  "http_to_reference_publish_ms": {
    "p50": 11.83466300000191,
    "p95": 20.327849000000242,
    "max": 22.152930999993714
  },
  "takeover_seams": [
    {
      "t": 147.363084895,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1424.50390625,
      "controller": 345.65234375,
      "publisher": 124.109375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1889.421875,
    "min_wsl_available_mib": 5608.90625,
    "nvml_gpu_peak_mib": 1290,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
