# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_115911_interactive_bounded_893248",
  "active_seconds": 16.127335668,
  "published_frames": 773,
  "debug_samples": 807,
  "physics_samples": 402,
  "fall_count": 0,
  "publish_hz": 47.929432173860114,
  "debug_hz": 50.01892891895058,
  "realtime_factor": 0.5000531447381562,
  "spring_disabled": true,
  "base_height_min_m": 0.7581617330709253,
  "base_height_max_m": 0.7861745946172706,
  "actual_base_displacement_m": 0.09495658174861843,
  "actual_base_path_length_m": 0.3470967304337753,
  "tracking_rmse_rad": 0.15217054311206923,
  "left_arm_tracking_rmse_rad": 0.13859582923107355,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2509403160409477e-08,
    "p95": 1.541148623599801e-08,
    "max": 1.799257981066085e-08
  },
  "target_observation_lag_ms": {
    "p50": 44.619434000026104,
    "p95": 47.592436100029545,
    "max": 52.63787499995942
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.1639110147953033,
  "left_arm_reference_speed_max_rad_s": 0.15662433289545158,
  "left_arm_reference_accel_max_rad_s2": 4.704855078600674,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7169099999941864,
    "p95": 25.053410199973314,
    "max": 59.04358099996898
  },
  "physics_sample_gap_ms": {
    "p50": 38.68934500002297,
    "p95": 76.52344399997446,
    "max": 136.35511799998312
  },
  "feedback_sample_gap_ms": {
    "p50": 20.031776500019305,
    "p95": 22.50362675000872,
    "max": 29.65336799996976
  },
  "publish_interval_ms": {
    "p50": 20.00267200000394,
    "p95": 28.140062599990756,
    "max": 62.74300300003688
  },
  "scheduling_lateness_ms": {
    "p50": 0.09591200489467155,
    "p95": 50.77342920011459,
    "max": 123.59967400016103
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.433,
      "p95": 5.85605,
      "max": 5.908
    },
    "policy": {
      "p50": 3.425,
      "p95": 4.8153,
      "max": 4.825
    },
    "observation_to_motor": {
      "p50": 7.842499999999999,
      "p95": 10.48465,
      "max": 10.733
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1440.39453125,
      "controller": 341.83203125,
      "publisher": 94.92578125,
      "viewer": 0
    },
    "max_sum_rss_mib": 1868.71484375,
    "min_wsl_available_mib": 5626.578125,
    "nvml_gpu_peak_mib": 1564,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
