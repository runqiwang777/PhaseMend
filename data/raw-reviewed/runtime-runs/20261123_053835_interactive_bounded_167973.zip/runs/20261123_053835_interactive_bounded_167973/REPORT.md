# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_053835_interactive_bounded_167973",
  "active_seconds": 38.19663412299997,
  "published_frames": 1889,
  "debug_samples": 1910,
  "physics_samples": 1910,
  "fall_count": 0,
  "publish_hz": 49.45510599959595,
  "debug_hz": 49.99983329154575,
  "realtime_factor": 0.999981516056596,
  "spring_disabled": true,
  "base_height_min_m": 0.7503101257675562,
  "base_height_max_m": 0.7763496876481927,
  "actual_base_displacement_m": 0.0302152649795454,
  "actual_base_path_length_m": 0.2884177298528934,
  "tracking_rmse_rad": 0.2176662404397266,
  "left_arm_tracking_rmse_rad": 0.24317070231142043,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.242091721965561e-08,
    "p95": 1.640482536846555e-08,
    "max": 1.95036253734582e-08
  },
  "target_observation_lag_ms": {
    "p50": 77.92263300007107,
    "p95": 78.58479239996541,
    "max": 81.16369999993367
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.2530517652630806,
  "left_arm_reference_speed_max_rad_s": 0.7809493925116228,
  "left_arm_reference_accel_max_rad_s2": 180.7898834835774,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7224999999380088,
    "p95": 1.2429336001332558,
    "max": 38.193426999896474
  },
  "physics_sample_gap_ms": {
    "p50": 19.99219100002847,
    "p95": 20.77051080009369,
    "max": 60.58784999981981
  },
  "feedback_sample_gap_ms": {
    "p50": 20.003932000008717,
    "p95": 20.836744199914392,
    "max": 23.499141000002055
  },
  "publish_interval_ms": {
    "p50": 20.000708999987182,
    "p95": 20.192918900170298,
    "max": 41.74942899999223
  },
  "scheduling_lateness_ms": {
    "p50": 0.11402700602047844,
    "p95": 0.8432680188434192,
    "max": 112.10052200044629
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.758,
      "p95": 4.9727,
      "max": 5.449
    },
    "policy": {
      "p50": 3.7039999999999997,
      "p95": 3.8693,
      "max": 3.933
    },
    "observation_to_motor": {
      "p50": 8.463999999999999,
      "p95": 8.67765,
      "max": 9.316
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1420.97265625,
      "controller": 343.515625,
      "publisher": 97.00390625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1856.6484375,
    "min_wsl_available_mib": 5624.62109375,
    "nvml_gpu_peak_mib": 1331,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
