# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261122_204112_interactive_bounded_174717",
  "active_seconds": 15.840172792000004,
  "published_frames": 792,
  "debug_samples": 778,
  "physics_samples": 767,
  "fall_count": 0,
  "publish_hz": 50.001566038302094,
  "debug_hz": 49.1539652927367,
  "realtime_factor": 0.967995253739126,
  "spring_disabled": true,
  "base_height_min_m": 0.7559076255898375,
  "base_height_max_m": 0.7756221834962181,
  "actual_base_displacement_m": 0.006901342731982981,
  "actual_base_path_length_m": 0.10991317381316992,
  "tracking_rmse_rad": 0.11899419111121037,
  "left_arm_tracking_rmse_rad": 0.1595314389329769,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2388373088719303e-08,
    "p95": 1.542035249537128e-08,
    "max": 0.00036787247536362465
  },
  "target_observation_lag_ms": {
    "p50": 595.5558269999983,
    "p95": 836.4316351500249,
    "max": 875.6155330000013
  },
  "max_reference_edit_rad": 0.6661331882213195,
  "left_shoulder_actual_range_rad": 0.04614350199699402,
  "left_arm_reference_speed_max_rad_s": 0.22385817729017043,
  "left_arm_reference_accel_max_rad_s2": 7.999999999999951,
  "intervention_selected_speed_max_rad_s": 0.9599999999999942,
  "intervention_selected_accel_max_rad_s2": 8.000000000000023,
  "edit_compute_ms": {
    "p50": 3.3732169999893813,
    "p95": 7.152060899996108,
    "max": 17.108978999999636
  },
  "physics_sample_gap_ms": {
    "p50": 20.109893000011425,
    "p95": 25.609029749993795,
    "max": 65.19091799998478
  },
  "feedback_sample_gap_ms": {
    "p50": 20.054426000001513,
    "p95": 27.611936400006694,
    "max": 283.03520200000776
  },
  "publish_interval_ms": {
    "p50": 20.000814000013634,
    "p95": 20.16315450001116,
    "max": 55.878075999999055
  },
  "scheduling_lateness_ms": {
    "p50": 0.11092449945238059,
    "p95": 0.34736749399115724,
    "max": 35.97966899650373
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 1.177,
      "p95": 6.232599999999998,
      "max": 7.143
    },
    "policy": {
      "p50": 0.584,
      "p95": 7.140399999999999,
      "max": 10.74
    },
    "observation_to_motor": {
      "p50": 1.805,
      "p95": 12.223299999999998,
      "max": 13.289
    }
  },
  "http_command_queue_ms": {
    "p50": 4.786833500006082,
    "p95": 17.15513560000943,
    "max": 53.078674999994746
  },
  "http_to_reference_publish_ms": {
    "p50": 11.250997999994183,
    "p95": 22.898007000010523,
    "max": 57.793497999995225
  },
  "takeover_seams": [
    {
      "t": 146.163195716,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1476.71875,
      "controller": 342.0078125,
      "publisher": 168.48046875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1983.45703125,
    "min_wsl_available_mib": 5602.5,
    "nvml_gpu_peak_mib": 1529,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
