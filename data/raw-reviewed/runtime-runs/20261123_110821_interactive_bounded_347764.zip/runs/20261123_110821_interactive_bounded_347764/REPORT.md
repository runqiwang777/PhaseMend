# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_110821_interactive_bounded_347764",
  "active_seconds": 6.930026232999978,
  "published_frames": 298,
  "debug_samples": 347,
  "physics_samples": 70,
  "fall_count": 0,
  "publish_hz": 42.98475909268284,
  "debug_hz": 49.998503946499,
  "realtime_factor": 0.2009863944437203,
  "spring_disabled": true,
  "base_height_min_m": 0.6828381079071484,
  "base_height_max_m": 0.7777270140855113,
  "actual_base_displacement_m": 0.06803633998822796,
  "actual_base_path_length_m": 0.19143368328569746,
  "tracking_rmse_rad": 0.21614074414733767,
  "left_arm_tracking_rmse_rad": 0.25602130094371733,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.3138007734138287e-08,
    "p95": 1.5210574393483818e-08,
    "max": 1.732671007285738e-08
  },
  "target_observation_lag_ms": {
    "p50": 92.16946700001927,
    "p95": 99.49909179999848,
    "max": 108.09495600000218
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.2018516212701797,
  "left_arm_reference_speed_max_rad_s": 0.216145118977469,
  "left_arm_reference_accel_max_rad_s2": 20.420350148025886,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 1.29717449999589,
    "p95": 33.07983170000454,
    "max": 36.160570999982156
  },
  "physics_sample_gap_ms": {
    "p50": 101.43850899999052,
    "p95": 164.58946680000963,
    "max": 185.11102899998377
  },
  "feedback_sample_gap_ms": {
    "p50": 20.011197000002312,
    "p95": 22.376289999982646,
    "max": 34.942118999993
  },
  "publish_interval_ms": {
    "p50": 20.007911999982753,
    "p95": 37.50684440000214,
    "max": 40.678547000027265
  },
  "scheduling_lateness_ms": {
    "p50": 0.1298100023632287,
    "p95": 88.77828250008119,
    "max": 113.94487200016101
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 1.241,
      "p95": 8.116399999999993,
      "max": 10.901
    },
    "policy": {
      "p50": 0.596,
      "p95": 2.486699999999995,
      "max": 4.581
    },
    "observation_to_motor": {
      "p50": 1.796,
      "p95": 10.603099999999989,
      "max": 15.482
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": false,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.83984375,
      "controller": 340.3203125,
      "publisher": 97.49609375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1873.25,
    "min_wsl_available_mib": 5621.56640625,
    "nvml_gpu_peak_mib": 1795,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
