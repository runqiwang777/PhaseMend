# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_042631_interactive_bounded_756533",
  "active_seconds": 39.42011489000001,
  "published_frames": 1971,
  "debug_samples": 1970,
  "physics_samples": 1972,
  "fall_count": 0,
  "publish_hz": 50.000813371099234,
  "debug_hz": 49.99767911738449,
  "realtime_factor": 1.0000106637358914,
  "spring_disabled": true,
  "base_height_min_m": 0.7362368585406163,
  "base_height_max_m": 0.7763844969953002,
  "actual_base_displacement_m": 0.0024292341404825303,
  "actual_base_path_length_m": 0.2843852955246394,
  "tracking_rmse_rad": 0.12627351070118892,
  "left_arm_tracking_rmse_rad": 0.17765313402664293,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.1627945351841524e-08,
    "p95": 1.497476774676387e-08,
    "max": 1.738988869021074e-08
  },
  "target_observation_lag_ms": {
    "p50": 76.98089000000152,
    "p95": 79.52689315000612,
    "max": 117.75586299998508
  },
  "max_reference_edit_rad": 0.7956383213630065,
  "left_shoulder_actual_range_rad": 0.2579901069402694,
  "left_arm_reference_speed_max_rad_s": 0.1968098091069998,
  "left_arm_reference_accel_max_rad_s2": 7.5000000000001705,
  "intervention_selected_speed_max_rad_s": 0.7640273437553999,
  "intervention_selected_accel_max_rad_s2": 7.500000000000905,
  "edit_compute_ms": {
    "p50": 1.9600629999843022,
    "p95": 3.4598674999983814,
    "max": 6.221863000007488
  },
  "physics_sample_gap_ms": {
    "p50": 20.002853999983472,
    "p95": 20.924777000004724,
    "max": 57.43248100000642
  },
  "feedback_sample_gap_ms": {
    "p50": 19.99230199999147,
    "p95": 22.264543400001457,
    "max": 31.494575000010627
  },
  "publish_interval_ms": {
    "p50": 19.999496500005876,
    "p95": 20.072616050005365,
    "max": 49.67800000000011
  },
  "scheduling_lateness_ms": {
    "p50": 0.08383999511352158,
    "p95": 0.16099948896908245,
    "max": 29.76577398467839
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.792,
      "p95": 4.94685,
      "max": 5.047
    },
    "policy": {
      "p50": 3.7515,
      "p95": 3.86435,
      "max": 4.036
    },
    "observation_to_motor": {
      "p50": 8.523499999999999,
      "p95": 8.7292,
      "max": 8.875
    }
  },
  "http_command_queue_ms": {
    "p50": 15.494018999987702,
    "p95": 17.98076499999297,
    "max": 45.66298399998914
  },
  "http_to_reference_publish_ms": {
    "p50": 18.26797399999691,
    "p95": 21.266051399987873,
    "max": 48.930652999985114
  },
  "takeover_seams": [
    {
      "t": 136.098055743,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1424.47265625,
      "controller": 345.5,
      "publisher": 115.99609375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1879.40625,
    "min_wsl_available_mib": 5608.40234375,
    "nvml_gpu_peak_mib": 1334,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
