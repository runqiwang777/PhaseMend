# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_120131_interactive_bounded_984006",
  "active_seconds": 38.10456367500001,
  "published_frames": 1868,
  "debug_samples": 1906,
  "physics_samples": 869,
  "fall_count": 0,
  "publish_hz": 49.02337586933034,
  "debug_hz": 50.0059669981056,
  "realtime_factor": 0.4566950846477118,
  "spring_disabled": true,
  "base_height_min_m": 0.7571635506857057,
  "base_height_max_m": 0.7764912503259063,
  "actual_base_displacement_m": 0.04678506693839978,
  "actual_base_path_length_m": 0.5107290650853962,
  "tracking_rmse_rad": 0.16353842008885286,
  "left_arm_tracking_rmse_rad": 0.15712123271658113,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.202148249288117e-08,
    "p95": 1.5404834740776374e-08,
    "max": 1.9543261923437793e-08
  },
  "target_observation_lag_ms": {
    "p50": 129.5904524999969,
    "p95": 131.60426799999811,
    "max": 144.62702200000876
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.08887313306331635,
  "left_arm_reference_speed_max_rad_s": 0.30116889109670486,
  "left_arm_reference_accel_max_rad_s2": 16.201338170523687,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.715899499994066,
    "p95": 1.6260225499905794,
    "max": 60.33181700001933
  },
  "physics_sample_gap_ms": {
    "p50": 40.29225100001099,
    "p95": 89.35197215001551,
    "max": 177.72463200003585
  },
  "feedback_sample_gap_ms": {
    "p50": 20.047319000013886,
    "p95": 22.315011000000595,
    "max": 33.87702300000228
  },
  "publish_interval_ms": {
    "p50": 20.000999999979285,
    "p95": 20.095555899990813,
    "max": 63.130236000006335
  },
  "scheduling_lateness_ms": {
    "p50": 0.08661400872256309,
    "p95": 0.2085718220655503,
    "max": 115.7013810003491
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 5.421,
      "p95": 5.81,
      "max": 5.831
    },
    "policy": {
      "p50": 4.53,
      "p95": 4.7413,
      "max": 4.807
    },
    "observation_to_motor": {
      "p50": 9.998,
      "p95": 10.5019,
      "max": 10.566
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1439.94921875,
      "controller": 344.4921875,
      "publisher": 94.94140625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1869.5390625,
    "min_wsl_available_mib": 5613.80078125,
    "nvml_gpu_peak_mib": 1564,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
