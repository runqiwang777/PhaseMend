# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_095318_interactive_bounded_725766",
  "active_seconds": 38.08568061099999,
  "published_frames": 1872,
  "debug_samples": 1904,
  "physics_samples": 1904,
  "fall_count": 0,
  "publish_hz": 49.152851426627656,
  "debug_hz": 49.99463374993049,
  "realtime_factor": 1.0000169356516995,
  "spring_disabled": true,
  "base_height_min_m": 0.7601901676868049,
  "base_height_max_m": 0.7773596590304525,
  "actual_base_displacement_m": 0.017093414349380425,
  "actual_base_path_length_m": 0.3267735755268127,
  "tracking_rmse_rad": 0.12304014136389085,
  "left_arm_tracking_rmse_rad": 0.17717184707274244,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.1789535497233874e-08,
    "p95": 1.535671741378909e-08,
    "max": 1.797226604758959e-08
  },
  "target_observation_lag_ms": {
    "p50": 243.73821150000197,
    "p95": 246.4008739499988,
    "max": 250.83687699998336
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.23254242539405817,
  "left_arm_reference_speed_max_rad_s": 0.24157651838180727,
  "left_arm_reference_accel_max_rad_s2": 34.726733839827034,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.76126449999947,
    "p95": 1.41763355000961,
    "max": 40.08440999999152
  },
  "physics_sample_gap_ms": {
    "p50": 19.975362000025143,
    "p95": 20.985687999996117,
    "max": 58.80305399998065
  },
  "feedback_sample_gap_ms": {
    "p50": 19.995281000007026,
    "p95": 22.16969759999756,
    "max": 27.490588000006255
  },
  "publish_interval_ms": {
    "p50": 20.000686999992467,
    "p95": 20.132265499995583,
    "max": 44.29831300001297
  },
  "scheduling_lateness_ms": {
    "p50": 0.09610049519892527,
    "p95": 0.24136733756137033,
    "max": 112.64587099981327
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.9085,
      "p95": 5.211399999999999,
      "max": 5.33
    },
    "policy": {
      "p50": 4.5285,
      "p95": 4.6706,
      "max": 4.761
    },
    "observation_to_motor": {
      "p50": 9.477,
      "p95": 9.683,
      "max": 9.775
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1422.45703125,
      "controller": 344.09765625,
      "publisher": 104.74609375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1865.83203125,
    "min_wsl_available_mib": 5622.3515625,
    "nvml_gpu_peak_mib": 1122,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
