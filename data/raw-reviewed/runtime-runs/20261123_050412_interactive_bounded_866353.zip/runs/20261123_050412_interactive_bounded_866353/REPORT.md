# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_050412_interactive_bounded_866353",
  "active_seconds": 38.096995792,
  "published_frames": 1879,
  "debug_samples": 1905,
  "physics_samples": 1905,
  "fall_count": 0,
  "publish_hz": 49.32184007332888,
  "debug_hz": 49.9999299646464,
  "realtime_factor": 1.0000073716930535,
  "spring_disabled": true,
  "base_height_min_m": 0.7526043028257461,
  "base_height_max_m": 0.777062814885381,
  "actual_base_displacement_m": 0.004904595590471056,
  "actual_base_path_length_m": 0.24883602166779584,
  "tracking_rmse_rad": 0.1271910827593107,
  "left_arm_tracking_rmse_rad": 0.1800838169033004,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.1572017403928866e-08,
    "p95": 1.4751555062495066e-08,
    "max": 1.772494425911178e-08
  },
  "target_observation_lag_ms": {
    "p50": 134.47369499999695,
    "p95": 135.2795143999856,
    "max": 137.25111900001252
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.23149429261684412,
  "left_arm_reference_speed_max_rad_s": 0.10291519039476722,
  "left_arm_reference_accel_max_rad_s2": 9.86351142663228,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7229139999935796,
    "p95": 1.121606400005248,
    "max": 30.75463700000114
  },
  "physics_sample_gap_ms": {
    "p50": 19.997524999993743,
    "p95": 20.97019745001063,
    "max": 58.83491999998114
  },
  "feedback_sample_gap_ms": {
    "p50": 19.987995999997565,
    "p95": 20.955294200000196,
    "max": 24.5753739999941
  },
  "publish_interval_ms": {
    "p50": 20.00146499999289,
    "p95": 20.165843650002554,
    "max": 45.69936900000471
  },
  "scheduling_lateness_ms": {
    "p50": 0.11856898865403309,
    "p95": 1.1554918953066757,
    "max": 105.70284499985405
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.742,
      "p95": 4.92535,
      "max": 5.06
    },
    "policy": {
      "p50": 3.684,
      "p95": 3.85985,
      "max": 3.928
    },
    "observation_to_motor": {
      "p50": 8.4525,
      "p95": 8.647450000000001,
      "max": 8.728
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1421.22265625,
      "controller": 344.0703125,
      "publisher": 94.828125,
      "viewer": 0
    },
    "max_sum_rss_mib": 1855.12109375,
    "min_wsl_available_mib": 5636.65625,
    "nvml_gpu_peak_mib": 1331,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
