# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_120546_interactive_bounded_187180",
  "active_seconds": 17.883290283999997,
  "published_frames": 863,
  "debug_samples": 894,
  "physics_samples": 408,
  "fall_count": 0,
  "publish_hz": 48.257015191492876,
  "debug_hz": 49.9987654840088,
  "realtime_factor": 0.45646590328245656,
  "spring_disabled": true,
  "base_height_min_m": 0.7490046817036681,
  "base_height_max_m": 0.7734614903575806,
  "actual_base_displacement_m": 0.10262160500092771,
  "actual_base_path_length_m": 0.3152610320183762,
  "tracking_rmse_rad": 0.15954138450382818,
  "left_arm_tracking_rmse_rad": 0.15597170393057802,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2490614431607476e-08,
    "p95": 1.5493739671585146e-08,
    "max": 1.799257981066085e-08
  },
  "target_observation_lag_ms": {
    "p50": 129.1639065000112,
    "p95": 130.71624855000437,
    "max": 137.53770899998585
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.14798572659492487,
  "left_arm_reference_speed_max_rad_s": 0.4211313424877799,
  "left_arm_reference_accel_max_rad_s2": 99.28343839494545,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7180240000081994,
    "p95": 25.238496300002566,
    "max": 49.06818199998497
  },
  "physics_sample_gap_ms": {
    "p50": 40.79235000000381,
    "p95": 81.43106469998429,
    "max": 177.51831100000004
  },
  "feedback_sample_gap_ms": {
    "p50": 20.019639999986794,
    "p95": 21.534731599990664,
    "max": 32.56689599999163
  },
  "publish_interval_ms": {
    "p50": 20.002623500005257,
    "p95": 28.43778289998368,
    "max": 51.83633300001134
  },
  "scheduling_lateness_ms": {
    "p50": 0.0943599993661337,
    "p95": 39.764418999939714,
    "max": 108.68696599985128
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 3.3280000000000003,
      "p95": 5.7653,
      "max": 5.896
    },
    "policy": {
      "p50": 2.1445,
      "p95": 4.73535,
      "max": 4.995
    },
    "observation_to_motor": {
      "p50": 5.38,
      "p95": 10.4705,
      "max": 10.782
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1440.96875,
      "controller": 342.38671875,
      "publisher": 95.5234375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1871.53515625,
    "min_wsl_available_mib": 5624.921875,
    "nvml_gpu_peak_mib": 1564,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
