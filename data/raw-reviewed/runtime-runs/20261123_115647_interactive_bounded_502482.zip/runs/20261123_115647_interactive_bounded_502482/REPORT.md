# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_115647_interactive_bounded_502482",
  "active_seconds": 16.640739394999997,
  "published_frames": 806,
  "debug_samples": 832,
  "physics_samples": 406,
  "fall_count": 0,
  "publish_hz": 48.435568341681815,
  "debug_hz": 50.016831259587235,
  "realtime_factor": 0.4871117204762825,
  "spring_disabled": true,
  "base_height_min_m": 0.758768094656865,
  "base_height_max_m": 0.7850741229744553,
  "actual_base_displacement_m": 0.09727115874619924,
  "actual_base_path_length_m": 0.34237007521616847,
  "tracking_rmse_rad": 0.1590942169467777,
  "left_arm_tracking_rmse_rad": 0.15387789777923855,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2282826030196285e-08,
    "p95": 1.5406642673362227e-08,
    "max": 1.799257981066085e-08
  },
  "target_observation_lag_ms": {
    "p50": 139.17452200000469,
    "p95": 142.5685202000082,
    "max": 149.05742900000973
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.2025639116764068,
  "left_arm_reference_speed_max_rad_s": 0.5938688218882727,
  "left_arm_reference_accel_max_rad_s2": 144.22753273155485,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7140130000067302,
    "p95": 24.038593250011786,
    "max": 34.77787799999987
  },
  "physics_sample_gap_ms": {
    "p50": 40.89010699999562,
    "p95": 71.16260219999617,
    "max": 114.31499400001144
  },
  "feedback_sample_gap_ms": {
    "p50": 19.978784000016958,
    "p95": 22.361635999999407,
    "max": 29.844966000013073
  },
  "publish_interval_ms": {
    "p50": 20.001333999999815,
    "p95": 27.746432000003537,
    "max": 45.93537899998523
  },
  "scheduling_lateness_ms": {
    "p50": 0.08900749814699793,
    "p95": 60.2647152499145,
    "max": 108.50919099988232
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 5.544499999999999,
      "p95": 5.88035,
      "max": 5.892
    },
    "policy": {
      "p50": 4.4415,
      "p95": 4.7649,
      "max": 5.104
    },
    "observation_to_motor": {
      "p50": 9.958,
      "p95": 10.53695,
      "max": 10.787
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1440.87890625,
      "controller": 340.72265625,
      "publisher": 98.69921875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1872.64453125,
    "min_wsl_available_mib": 5624.14453125,
    "nvml_gpu_peak_mib": 1510,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
