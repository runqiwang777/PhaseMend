# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_051431_interactive_bounded_425468",
  "active_seconds": 38.02069389999997,
  "published_frames": 1880,
  "debug_samples": 1901,
  "physics_samples": 1901,
  "fall_count": 0,
  "publish_hz": 49.44709033582156,
  "debug_hz": 50.000322884979845,
  "realtime_factor": 0.9999813552950628,
  "spring_disabled": true,
  "base_height_min_m": 0.750760795308895,
  "base_height_max_m": 0.776509570212255,
  "actual_base_displacement_m": 0.016798380585545558,
  "actual_base_path_length_m": 0.22106552528601556,
  "tracking_rmse_rad": 0.11637609359881812,
  "left_arm_tracking_rmse_rad": 0.16830533135029863,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.1630262860099335e-08,
    "p95": 1.507923420115295e-08,
    "max": 1.76571289191966e-08
  },
  "target_observation_lag_ms": {
    "p50": 72.1100649999471,
    "p95": 72.9377545000034,
    "max": 76.85730099996135
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.14415201544761652,
  "left_arm_reference_speed_max_rad_s": 0.2745851438868504,
  "left_arm_reference_accel_max_rad_s2": 36.96579641520651,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.72612299999264,
    "p95": 1.5675222500192332,
    "max": 49.374325999963276
  },
  "physics_sample_gap_ms": {
    "p50": 19.99747249999473,
    "p95": 20.775516800009086,
    "max": 52.353749000019434
  },
  "feedback_sample_gap_ms": {
    "p50": 19.98880050001617,
    "p95": 20.882903199972702,
    "max": 24.72543799996174
  },
  "publish_interval_ms": {
    "p50": 20.000512000024173,
    "p95": 20.19457480003552,
    "max": 51.74389000001156
  },
  "scheduling_lateness_ms": {
    "p50": 0.08802251517181503,
    "p95": 0.2840495248165082,
    "max": 111.76030900031719
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.709,
      "p95": 5.005,
      "max": 5.86
    },
    "policy": {
      "p50": 3.309,
      "p95": 3.854,
      "max": 3.885
    },
    "observation_to_motor": {
      "p50": 8.236,
      "p95": 8.632,
      "max": 9.662
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1424.1953125,
      "controller": 344.234375,
      "publisher": 93.0234375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1861.453125,
    "min_wsl_available_mib": 5615.296875,
    "nvml_gpu_peak_mib": 1331,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
