# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_102052_interactive_bounded_146681",
  "active_seconds": 38.133432462,
  "published_frames": 1881,
  "debug_samples": 1907,
  "physics_samples": 1907,
  "fall_count": 0,
  "publish_hz": 49.32721212961793,
  "debug_hz": 50.01283349774506,
  "realtime_factor": 0.9996622846565302,
  "spring_disabled": true,
  "base_height_min_m": 0.747999954340948,
  "base_height_max_m": 0.7757547364599331,
  "actual_base_displacement_m": 0.03503453490727712,
  "actual_base_path_length_m": 0.37361363809913195,
  "tracking_rmse_rad": 0.12965062869157296,
  "left_arm_tracking_rmse_rad": 0.1874549897114954,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2026590201710842e-08,
    "p95": 1.5404374042099136e-08,
    "max": 1.9543261923437793e-08
  },
  "target_observation_lag_ms": {
    "p50": 155.85064100000068,
    "p95": 161.5622743000074,
    "max": 175.90075300000763
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.221022330224514,
  "left_arm_reference_speed_max_rad_s": 0.3009278657487517,
  "left_arm_reference_accel_max_rad_s2": 16.55098392773708,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7346629999744891,
    "p95": 2.11468300000206,
    "max": 30.806940000019267
  },
  "physics_sample_gap_ms": {
    "p50": 19.99264600000572,
    "p95": 21.12575799999661,
    "max": 54.42841199999293
  },
  "feedback_sample_gap_ms": {
    "p50": 19.998838000006458,
    "p95": 25.203845749992126,
    "max": 36.102762000012945
  },
  "publish_interval_ms": {
    "p50": 20.0010825000021,
    "p95": 20.698921649994865,
    "max": 40.933846000001495
  },
  "scheduling_lateness_ms": {
    "p50": 0.0897919860562979,
    "p95": 0.9574279961839238,
    "max": 104.43478199982792
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.5505,
      "p95": 6.56345,
      "max": 7.797
    },
    "policy": {
      "p50": 2.1195000000000004,
      "p95": 2.6880499999999996,
      "max": 6.058
    },
    "observation_to_motor": {
      "p50": 4.7989999999999995,
      "p95": 8.649149999999999,
      "max": 10.113
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1421.078125,
      "controller": 344.5546875,
      "publisher": 99.32421875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1859.48828125,
    "min_wsl_available_mib": 5629.94140625,
    "nvml_gpu_peak_mib": 1637,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
