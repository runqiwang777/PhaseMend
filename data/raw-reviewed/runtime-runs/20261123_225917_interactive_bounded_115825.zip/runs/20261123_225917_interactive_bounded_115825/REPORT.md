# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_225917_interactive_bounded_115825",
  "active_seconds": 146.210216809,
  "published_frames": 7274,
  "debug_samples": 7311,
  "physics_samples": 2926,
  "fall_count": 0,
  "publish_hz": 49.75039559894597,
  "debug_hz": 50.00005121482675,
  "realtime_factor": 0.4004545542092218,
  "spring_disabled": true,
  "base_height_min_m": 0.7698497235302527,
  "base_height_max_m": 0.7748127268079729,
  "actual_base_displacement_m": 0.06950669419923716,
  "actual_base_path_length_m": 0.07562461823527805,
  "tracking_rmse_rad": 0.4376984361007303,
  "left_arm_tracking_rmse_rad": 0.1539390132288036,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2400873687409261e-08,
    "p95": 1.4914394056419366e-08,
    "max": 1.8952723637132984e-08
  },
  "target_observation_lag_ms": {
    "p50": 192.37848349999354,
    "p95": 193.19967310001687,
    "max": 202.8376279999975
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.008892342448234558,
  "left_arm_reference_speed_max_rad_s": 0.2743970448473374,
  "left_arm_reference_accel_max_rad_s2": 76.85666939508317,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7621160000041982,
    "p95": 0.9056712500040475,
    "max": 56.61371400000803
  },
  "physics_sample_gap_ms": {
    "p50": 44.17388400000277,
    "p95": 98.69466079998686,
    "max": 189.0112199999976
  },
  "feedback_sample_gap_ms": {
    "p50": 19.992622499998447,
    "p95": 20.99546785000115,
    "max": 32.46516199999405
  },
  "publish_interval_ms": {
    "p50": 20.00028800000564,
    "p95": 20.068169000001035,
    "max": 59.195525999996335
  },
  "scheduling_lateness_ms": {
    "p50": 0.10347248000641684,
    "p95": 0.16195132045169197,
    "max": 110.95714499987253
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.772,
      "p95": 4.9299,
      "max": 5.256
    },
    "policy": {
      "p50": 3.656,
      "p95": 3.856,
      "max": 6.289
    },
    "observation_to_motor": {
      "p50": 8.423,
      "p95": 8.7168,
      "max": 11.546
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1440.1640625,
      "controller": 357.453125,
      "publisher": 100.8984375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1883.80859375,
    "min_wsl_available_mib": 5603.3359375,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
