# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_144515_interactive_bounded_595440",
  "active_seconds": 16.20429267000003,
  "published_frames": 778,
  "debug_samples": 811,
  "physics_samples": 367,
  "fall_count": 0,
  "publish_hz": 48.01050960510046,
  "debug_hz": 49.99977786518445,
  "realtime_factor": 0.4534422301347544,
  "spring_disabled": true,
  "base_height_min_m": 0.7669457002724214,
  "base_height_max_m": 0.778852438276557,
  "actual_base_displacement_m": 0.11142937102377712,
  "actual_base_path_length_m": 0.3067722285943133,
  "tracking_rmse_rad": 0.16402360633251323,
  "left_arm_tracking_rmse_rad": 0.16114099362590473,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2803548202032029e-08,
    "p95": 1.60206965015284e-08,
    "max": 1.8859122114888925e-08
  },
  "target_observation_lag_ms": {
    "p50": 116.3590770000269,
    "p95": 117.1793264999792,
    "max": 120.28863200004025
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.09831441938877106,
  "left_arm_reference_speed_max_rad_s": 0.2372016434731396,
  "left_arm_reference_accel_max_rad_s2": 9.273069676904822,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7311824999760574,
    "p95": 25.373587550018318,
    "max": 45.03861699998879
  },
  "physics_sample_gap_ms": {
    "p50": 40.421143000031634,
    "p95": 87.14109625000788,
    "max": 159.95216099997833
  },
  "feedback_sample_gap_ms": {
    "p50": 19.99158399999601,
    "p95": 21.006131499996172,
    "max": 24.046498000018346
  },
  "publish_interval_ms": {
    "p50": 20.002529999999297,
    "p95": 28.69118619997833,
    "max": 48.09450099998003
  },
  "scheduling_lateness_ms": {
    "p50": 0.10307700594580638,
    "p95": 45.718751600094265,
    "max": 115.34833800016031
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.7545,
      "p95": 5.0225,
      "max": 5.048
    },
    "policy": {
      "p50": 3.682,
      "p95": 3.7701,
      "max": 3.803
    },
    "observation_to_motor": {
      "p50": 8.4195,
      "p95": 8.710099999999999,
      "max": 8.851
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1440.6953125,
      "controller": 340.74609375,
      "publisher": 104.50390625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1878.1328125,
    "min_wsl_available_mib": 5611.47265625,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
