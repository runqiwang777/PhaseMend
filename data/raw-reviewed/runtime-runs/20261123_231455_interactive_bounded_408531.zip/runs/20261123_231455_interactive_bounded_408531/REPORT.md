# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_231455_interactive_bounded_408531",
  "active_seconds": 146.139523472,
  "published_frames": 7270,
  "debug_samples": 7307,
  "physics_samples": 2675,
  "fall_count": 0,
  "publish_hz": 49.74708234749086,
  "debug_hz": 50.00024647842553,
  "realtime_factor": 0.3661307567846992,
  "spring_disabled": true,
  "base_height_min_m": 0.7685472604640967,
  "base_height_max_m": 0.7745497698507843,
  "actual_base_displacement_m": 0.07351648128750125,
  "actual_base_path_length_m": 0.08251247903110763,
  "tracking_rmse_rad": 0.43404129546602715,
  "left_arm_tracking_rmse_rad": 0.14395657915105092,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2400873687409261e-08,
    "p95": 1.4915032135839265e-08,
    "max": 1.8952723637132984e-08
  },
  "target_observation_lag_ms": {
    "p50": 44.64810500000738,
    "p95": 64.77845514999387,
    "max": 67.84777799998665
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.006141200661659241,
  "left_arm_reference_speed_max_rad_s": 0.5095220700328116,
  "left_arm_reference_accel_max_rad_s2": 89.15649727980517,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7100179999923739,
    "p95": 0.8949738499850918,
    "max": 71.66726500000209
  },
  "physics_sample_gap_ms": {
    "p50": 48.1495749999965,
    "p95": 105.76625659998483,
    "max": 168.07970500002511
  },
  "feedback_sample_gap_ms": {
    "p50": 19.987657999990915,
    "p95": 22.29426625000741,
    "max": 33.514386000007335
  },
  "publish_interval_ms": {
    "p50": 20.000085000020817,
    "p95": 20.073898999999074,
    "max": 75.27357399999346
  },
  "scheduling_lateness_ms": {
    "p50": 0.09722047107629805,
    "p95": 0.17225738735646692,
    "max": 114.07829399988145
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.792,
      "p95": 4.9375,
      "max": 5.369
    },
    "policy": {
      "p50": 3.6665,
      "p95": 3.904,
      "max": 6.371
    },
    "observation_to_motor": {
      "p50": 8.4085,
      "p95": 8.73925,
      "max": 11.375
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.83203125,
      "controller": 357.28515625,
      "publisher": 95.03515625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1885.90234375,
    "min_wsl_available_mib": 5603.20703125,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
