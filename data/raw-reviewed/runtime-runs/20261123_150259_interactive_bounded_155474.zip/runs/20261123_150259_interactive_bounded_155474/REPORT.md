# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_150259_interactive_bounded_155474",
  "active_seconds": 38.092277017000015,
  "published_frames": 1888,
  "debug_samples": 1904,
  "physics_samples": 836,
  "fall_count": 0,
  "publish_hz": 49.5641562875727,
  "debug_hz": 50.000741185448334,
  "realtime_factor": 0.43903975015783114,
  "spring_disabled": true,
  "base_height_min_m": 0.729470690026775,
  "base_height_max_m": 0.7787464049572248,
  "actual_base_displacement_m": 0.04699054450663592,
  "actual_base_path_length_m": 0.5760059219762619,
  "tracking_rmse_rad": 0.17547662448196377,
  "left_arm_tracking_rmse_rad": 0.15947589415982585,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.307506269478334e-08,
    "p95": 1.669218914597439e-08,
    "max": 1.8952723637132984e-08
  },
  "target_observation_lag_ms": {
    "p50": 106.53099800001087,
    "p95": 107.44008430001486,
    "max": 120.5192420000003
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.1804521307349205,
  "left_arm_reference_speed_max_rad_s": 0.48112720766839934,
  "left_arm_reference_accel_max_rad_s2": 95.62040673826706,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.754407999991713,
    "p95": 2.2807173499941764,
    "max": 38.857479000000694
  },
  "physics_sample_gap_ms": {
    "p50": 40.52382099999363,
    "p95": 95.27337629998839,
    "max": 162.17653699999346
  },
  "feedback_sample_gap_ms": {
    "p50": 19.991932000010593,
    "p95": 20.981764900014355,
    "max": 33.91523799999163
  },
  "publish_interval_ms": {
    "p50": 20.001104999977315,
    "p95": 20.514638699998486,
    "max": 42.10655100001759
  },
  "scheduling_lateness_ms": {
    "p50": 0.0902254883499154,
    "p95": 1.4640357893311629,
    "max": 116.13832199972762
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.7435,
      "p95": 4.8982,
      "max": 4.963
    },
    "policy": {
      "p50": 3.574,
      "p95": 3.8886999999999996,
      "max": 6.229
    },
    "observation_to_motor": {
      "p50": 8.308499999999999,
      "p95": 8.674800000000001,
      "max": 11.138
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.8828125,
      "controller": 344.01953125,
      "publisher": 99.625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1875.21484375,
    "min_wsl_available_mib": 5619.70703125,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
