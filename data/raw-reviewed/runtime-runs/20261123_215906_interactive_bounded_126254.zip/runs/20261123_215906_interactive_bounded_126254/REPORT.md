# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_215906_interactive_bounded_126254",
  "active_seconds": 101.620833218,
  "published_frames": 5049,
  "debug_samples": 5081,
  "physics_samples": 2263,
  "fall_count": 0,
  "publish_hz": 49.684769923116335,
  "debug_hz": 49.99937139668248,
  "realtime_factor": 0.44532826892739386,
  "spring_disabled": true,
  "base_height_min_m": 0.7606330929458612,
  "base_height_max_m": 0.7895195852560662,
  "actual_base_displacement_m": 0.06967518619472224,
  "actual_base_path_length_m": 0.9664774805659357,
  "tracking_rmse_rad": 0.20081015508190364,
  "left_arm_tracking_rmse_rad": 0.16807392790492817,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2400873687409261e-08,
    "p95": 1.5480033760843984e-08,
    "max": 1.8952723637132984e-08
  },
  "target_observation_lag_ms": {
    "p50": 151.7911844999844,
    "p95": 152.96640445000662,
    "max": 169.36325099999294
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.12279829382896418,
  "left_arm_reference_speed_max_rad_s": 0.3320452607320261,
  "left_arm_reference_accel_max_rad_s2": 38.51125283103952,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7125710000082108,
    "p95": 0.9545338000009439,
    "max": 61.48842900000773
  },
  "physics_sample_gap_ms": {
    "p50": 39.46109100000683,
    "p95": 100.59405740000634,
    "max": 215.77683499998557
  },
  "feedback_sample_gap_ms": {
    "p50": 19.99223899998981,
    "p95": 21.162650899999846,
    "max": 37.55376799998089
  },
  "publish_interval_ms": {
    "p50": 20.000760499996773,
    "p95": 20.084085599989976,
    "max": 65.34140799999477
  },
  "scheduling_lateness_ms": {
    "p50": 0.10779895836776632,
    "p95": 0.18756118097940078,
    "max": 122.58673499991346
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.747,
      "p95": 4.96,
      "max": 5.351
    },
    "policy": {
      "p50": 3.56,
      "p95": 3.8331999999999997,
      "max": 4.282
    },
    "observation_to_motor": {
      "p50": 8.328,
      "p95": 8.6532,
      "max": 9.389
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.23828125,
      "controller": 351.95703125,
      "publisher": 98.7265625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1879.421875,
    "min_wsl_available_mib": 5607.140625,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
