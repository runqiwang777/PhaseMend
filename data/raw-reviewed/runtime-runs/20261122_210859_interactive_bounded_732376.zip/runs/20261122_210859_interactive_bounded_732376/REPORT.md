# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261122_210859_interactive_bounded_732376",
  "active_seconds": 15.880114851999991,
  "published_frames": 794,
  "debug_samples": 768,
  "physics_samples": 794,
  "fall_count": 0,
  "publish_hz": 50.00205739549895,
  "debug_hz": 48.361874548422485,
  "realtime_factor": 0.9999937308720962,
  "spring_disabled": true,
  "base_height_min_m": 0.7593788327282622,
  "base_height_max_m": 0.7712115139150261,
  "actual_base_displacement_m": 0.004890453287536203,
  "actual_base_path_length_m": 0.11851618282085333,
  "tracking_rmse_rad": 0.12870180942685516,
  "left_arm_tracking_rmse_rad": 0.1662578538542211,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2785118441819922e-08,
    "p95": 1.5534632257688888e-08,
    "max": 1.7136237749585474e-08
  },
  "target_observation_lag_ms": {
    "p50": 1089.1966040000227,
    "p95": 1346.5708524000036,
    "max": 1379.0243550000127
  },
  "max_reference_edit_rad": 0.7371432819159374,
  "left_shoulder_actual_range_rad": 0.06234343349933624,
  "left_arm_reference_speed_max_rad_s": 0.367433240684234,
  "left_arm_reference_accel_max_rad_s2": 7.999999999999951,
  "intervention_selected_speed_max_rad_s": 1.1784107669259358,
  "intervention_selected_accel_max_rad_s2": 8.000000000000023,
  "edit_compute_ms": {
    "p50": 1.9157175000117377,
    "p95": 3.145441649996883,
    "max": 6.088830000010148
  },
  "physics_sample_gap_ms": {
    "p50": 19.981954999991558,
    "p95": 21.168583399997942,
    "max": 71.2407169999949
  },
  "feedback_sample_gap_ms": {
    "p50": 19.93643400001588,
    "p95": 27.419506599997586,
    "max": 303.0698510000036
  },
  "publish_interval_ms": {
    "p50": 19.999052000002848,
    "p95": 20.07992440001658,
    "max": 44.27300700001524
  },
  "scheduling_lateness_ms": {
    "p50": 0.11365049614653344,
    "p95": 0.17509734604317367,
    "max": 24.43904899692484
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.325,
      "p95": 6.404199999999985,
      "max": 11.003
    },
    "policy": {
      "p50": 1.612,
      "p95": 7.188799999999998,
      "max": 10.228
    },
    "observation_to_motor": {
      "p50": 4.164,
      "p95": 12.325599999999998,
      "max": 12.903
    }
  },
  "http_command_queue_ms": {
    "p50": 3.3770800000070267,
    "p95": 16.711305799992715,
    "max": 19.43178100000864
  },
  "http_to_reference_publish_ms": {
    "p50": 6.153414999999995,
    "p95": 19.71120039997913,
    "max": 23.55186599999115
  },
  "takeover_seams": [
    {
      "t": 134.086093931,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1475.796875,
      "controller": 342.3203125,
      "publisher": 163.234375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1977.41796875,
    "min_wsl_available_mib": 5606.0,
    "nvml_gpu_peak_mib": 1602,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
