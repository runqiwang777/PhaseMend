# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_115012_interactive_bounded_328342",
  "active_seconds": 16.606520903000018,
  "published_frames": 804,
  "debug_samples": 831,
  "physics_samples": 389,
  "fall_count": 0,
  "publish_hz": 48.41389067502432,
  "debug_hz": 49.99793241381512,
  "realtime_factor": 0.46864352056694725,
  "spring_disabled": true,
  "base_height_min_m": 0.7636827402143539,
  "base_height_max_m": 0.7934088919462813,
  "actual_base_displacement_m": 0.11405770929155194,
  "actual_base_path_length_m": 0.3095659484596579,
  "tracking_rmse_rad": 0.16946417971253747,
  "left_arm_tracking_rmse_rad": 0.15275352422295843,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2514240000323898e-08,
    "p95": 1.5397672427748784e-08,
    "max": 1.799257981066085e-08
  },
  "target_observation_lag_ms": {
    "p50": 114.50689200000852,
    "p95": 116.25155419998805,
    "max": 123.49446499999317
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.23992997407913202,
  "left_arm_reference_speed_max_rad_s": 0.35736178979414257,
  "left_arm_reference_accel_max_rad_s2": 94.60271968953104,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.726851999999667,
    "p95": 21.934555599993626,
    "max": 59.15103600000293
  },
  "physics_sample_gap_ms": {
    "p50": 38.83821650001096,
    "p95": 89.00813764999911,
    "max": 154.98658100000284
  },
  "feedback_sample_gap_ms": {
    "p50": 20.00916449999579,
    "p95": 21.876545099993905,
    "max": 28.850120999976525
  },
  "publish_interval_ms": {
    "p50": 20.00245400000722,
    "p95": 25.06023429999401,
    "max": 61.925919999993084
  },
  "scheduling_lateness_ms": {
    "p50": 0.10895949682776518,
    "p95": 41.97572084996455,
    "max": 109.71473999990167
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.5600000000000005,
      "p95": 4.77475,
      "max": 4.805
    },
    "policy": {
      "p50": 4.3245000000000005,
      "p95": 4.774,
      "max": 4.793
    },
    "observation_to_motor": {
      "p50": 8.941500000000001,
      "p95": 9.48325,
      "max": 9.489
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.15625,
      "controller": 340.98046875,
      "publisher": 91.734375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1873.87109375,
    "min_wsl_available_mib": 5620.390625,
    "nvml_gpu_peak_mib": 1510,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
