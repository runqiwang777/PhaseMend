# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_024348_interactive_bounded_799288",
  "active_seconds": 39.58028349200001,
  "published_frames": 1979,
  "debug_samples": 1979,
  "physics_samples": 1979,
  "fall_count": 0,
  "publish_hz": 50.000354255543286,
  "debug_hz": 49.999050411108534,
  "realtime_factor": 1.00000100068321,
  "spring_disabled": true,
  "base_height_min_m": 0.7379006796572825,
  "base_height_max_m": 0.7868392303488796,
  "actual_base_displacement_m": 2.1244892136967306,
  "actual_base_path_length_m": 3.4260316620319675,
  "tracking_rmse_rad": 0.13353597849268542,
  "left_arm_tracking_rmse_rad": 0.16792271043040694,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 9.020948173046236e-09,
    "p95": 1.32875915264551e-08,
    "max": 1.7872553635491475e-08
  },
  "target_observation_lag_ms": null,
  "max_reference_edit_rad": 0.9470141705206783,
  "left_shoulder_actual_range_rad": 0.43224121630191803,
  "left_arm_reference_speed_max_rad_s": 10.127216387845206,
  "left_arm_reference_accel_max_rad_s2": 531.673110030827,
  "intervention_selected_speed_max_rad_s": 3.0127482302094357,
  "intervention_selected_accel_max_rad_s2": 243.82932467436876,
  "edit_compute_ms": {
    "p50": 2.3366050000106497,
    "p95": 3.32694030001619,
    "max": 6.110169000010046
  },
  "physics_sample_gap_ms": {
    "p50": 19.979329999998185,
    "p95": 20.959976549978876,
    "max": 66.34624899999153
  },
  "feedback_sample_gap_ms": {
    "p50": 19.989374500013923,
    "p95": 21.587147299983652,
    "max": 28.077874999979713
  },
  "publish_interval_ms": {
    "p50": 19.999773499989715,
    "p95": 20.10692239999088,
    "max": 55.34885599999484
  },
  "scheduling_lateness_ms": {
    "p50": 0.08154799320436723,
    "p95": 0.21346408996407712,
    "max": 35.47717698765496
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.769,
      "p95": 4.9643500000000005,
      "max": 5.027
    },
    "policy": {
      "p50": 3.7270000000000003,
      "p95": 3.8912999999999998,
      "max": 3.917
    },
    "observation_to_motor": {
      "p50": 8.4975,
      "p95": 8.701,
      "max": 8.759
    }
  },
  "http_command_queue_ms": {
    "p50": 10.294361999996227,
    "p95": 17.590925200011043,
    "max": 19.39421199998037
  },
  "http_to_reference_publish_ms": {
    "p50": 13.15661499998555,
    "p95": 20.716611599976883,
    "max": 27.21863800002211
  },
  "takeover_seams": [
    {
      "t": 133.387524327,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": true,
    "intervention_speed_limit": false,
    "intervention_acceleration_limit": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.6796875,
      "controller": 343.88671875,
      "publisher": 97.953125,
      "viewer": 0
    },
    "max_sum_rss_mib": 1860.36328125,
    "min_wsl_available_mib": 5622.859375,
    "nvml_gpu_peak_mib": 1290,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
