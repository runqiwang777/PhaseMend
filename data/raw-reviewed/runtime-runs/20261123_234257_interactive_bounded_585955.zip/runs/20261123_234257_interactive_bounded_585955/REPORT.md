# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_234257_interactive_bounded_585955",
  "active_seconds": 30.17723470699997,
  "published_frames": 1468,
  "debug_samples": 1509,
  "physics_samples": 650,
  "fall_count": 0,
  "publish_hz": 48.645573040157416,
  "debug_hz": 50.00120690081584,
  "realtime_factor": 0.43057554591423425,
  "spring_disabled": true,
  "base_height_min_m": 0.7229352027127989,
  "base_height_max_m": 0.7933609115551448,
  "actual_base_displacement_m": 0.1507296888398665,
  "actual_base_path_length_m": 0.3500401840825582,
  "tracking_rmse_rad": 0.2714704623564231,
  "left_arm_tracking_rmse_rad": 0.19725524189150961,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.304251927566716e-08,
    "p95": 1.6470232364815743e-08,
    "max": 1.8859122114888925e-08
  },
  "target_observation_lag_ms": {
    "p50": 57.13926499998934,
    "p95": 77.44180974998471,
    "max": 82.30324599998085
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.1537698656320572,
  "left_arm_reference_speed_max_rad_s": 1.2169440859038145,
  "left_arm_reference_accel_max_rad_s2": 309.4877493904688,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7175380000035148,
    "p95": 1.7412278000164882,
    "max": 70.02450000004501
  },
  "physics_sample_gap_ms": {
    "p50": 41.405686000018704,
    "p95": 96.68684399998712,
    "max": 191.54121200000418
  },
  "feedback_sample_gap_ms": {
    "p50": 19.99413949999962,
    "p95": 21.230774599982283,
    "max": 30.80863100001352
  },
  "publish_interval_ms": {
    "p50": 20.001820999993924,
    "p95": 20.58241989998919,
    "max": 74.09301299998106
  },
  "scheduling_lateness_ms": {
    "p50": 0.12119401043264588,
    "p95": 1.9365140686204008,
    "max": 131.0852520001049
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.809,
      "p95": 5.003,
      "max": 5.061
    },
    "policy": {
      "p50": 3.709,
      "p95": 3.854,
      "max": 3.922
    },
    "observation_to_motor": {
      "p50": 8.502,
      "p95": 8.78,
      "max": 8.882
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.7421875,
      "controller": 342.5859375,
      "publisher": 94.46484375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1870.04296875,
    "min_wsl_available_mib": 5618.7265625,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
