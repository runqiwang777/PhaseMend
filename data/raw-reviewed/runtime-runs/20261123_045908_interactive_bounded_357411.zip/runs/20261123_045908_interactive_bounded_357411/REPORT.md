# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_045908_interactive_bounded_357411",
  "active_seconds": 8.405734745000018,
  "published_frames": 405,
  "debug_samples": 421,
  "physics_samples": 421,
  "fall_count": 0,
  "publish_hz": 48.17899985603448,
  "debug_hz": 49.99715220982628,
  "realtime_factor": 1.0000179075830948,
  "spring_disabled": true,
  "base_height_min_m": 0.7580125545641061,
  "base_height_max_m": 0.7750284356380632,
  "actual_base_displacement_m": 0.02306298399679562,
  "actual_base_path_length_m": 0.051442660270938884,
  "tracking_rmse_rad": 0.10811519155457297,
  "left_arm_tracking_rmse_rad": 0.16579771391840553,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.259953782015098e-08,
    "p95": 1.4517824600289957e-08,
    "max": 1.722637074590797e-08
  },
  "target_observation_lag_ms": {
    "p50": 117.51223699997126,
    "p95": 120.5912501000114,
    "max": 157.79361000005565
  },
  "max_reference_edit_rad": 0.022268830772157466,
  "left_shoulder_actual_range_rad": 0.13314598798751826,
  "left_arm_reference_speed_max_rad_s": 0.1667360965458325,
  "left_arm_reference_accel_max_rad_s2": 7.5000000000008535,
  "intervention_selected_speed_max_rad_s": 0.1651047970986922,
  "intervention_selected_accel_max_rad_s2": 20.334172136027977,
  "edit_compute_ms": {
    "p50": 2.111758000012287,
    "p95": 22.664332199985886,
    "max": 37.28734900005293
  },
  "physics_sample_gap_ms": {
    "p50": 19.98532050001245,
    "p95": 20.873031450020104,
    "max": 61.311626000019714
  },
  "feedback_sample_gap_ms": {
    "p50": 19.95990549997373,
    "p95": 22.183034550008074,
    "max": 25.578556999960256
  },
  "publish_interval_ms": {
    "p50": 20.00375100001861,
    "p95": 25.42950390001976,
    "max": 48.30706799998552
  },
  "scheduling_lateness_ms": {
    "p50": 0.0929610050093288,
    "p95": 73.20385400031437,
    "max": 103.1328350005083
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.67,
      "p95": 4.9368,
      "max": 5.427
    },
    "policy": {
      "p50": 3.7030000000000003,
      "p95": 3.8914000000000004,
      "max": 4.241
    },
    "observation_to_motor": {
      "p50": 8.389500000000002,
      "p95": 8.9292,
      "max": 8.971
    }
  },
  "http_command_queue_ms": {
    "p50": 3.2341134999853693,
    "p95": 17.60317465002572,
    "max": 22.794103000023824
  },
  "http_to_reference_publish_ms": {
    "p50": 5.823155000001634,
    "p95": 20.728413350011007,
    "max": 52.59358500001099
  },
  "takeover_seams": [
    {
      "t": 364.698406088,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.828125,
      "controller": 340.12890625,
      "publisher": 94.2421875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1856.63671875,
    "min_wsl_available_mib": 5626.30078125,
    "nvml_gpu_peak_mib": 1331,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
