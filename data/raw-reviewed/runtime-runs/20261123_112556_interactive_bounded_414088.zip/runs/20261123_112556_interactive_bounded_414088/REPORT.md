# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_112556_interactive_bounded_414088",
  "active_seconds": 38.107999518999975,
  "published_frames": 1856,
  "debug_samples": 1898,
  "physics_samples": 582,
  "fall_count": 0,
  "publish_hz": 48.70403268632647,
  "debug_hz": 49.816174896826205,
  "realtime_factor": 0.3054123602429858,
  "spring_disabled": true,
  "base_height_min_m": 0.7475049455995051,
  "base_height_max_m": 0.7708842854753468,
  "actual_base_displacement_m": 0.07939669404511447,
  "actual_base_path_length_m": 0.20042810186871682,
  "tracking_rmse_rad": 0.1265058950334344,
  "left_arm_tracking_rmse_rad": 0.1696177925039087,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2025893960586433e-08,
    "p95": 1.5408662275712315e-08,
    "max": 1.9543261923437793e-08
  },
  "target_observation_lag_ms": {
    "p50": 420.817698999997,
    "p95": 426.69219099999225,
    "max": 451.8581089999998
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.13370211422443384,
  "left_arm_reference_speed_max_rad_s": 0.32928904854356605,
  "left_arm_reference_accel_max_rad_s2": 4.922783130769951,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 1.0628389999993715,
    "p95": 2.189696249985218,
    "max": 57.17118800001231
  },
  "physics_sample_gap_ms": {
    "p50": 55.87554999999611,
    "p95": 124.68446099998687,
    "max": 219.79406299999482
  },
  "feedback_sample_gap_ms": {
    "p50": 20.014623999998093,
    "p95": 22.255354400004983,
    "max": 112.84116000001632
  },
  "publish_interval_ms": {
    "p50": 20.000709000015604,
    "p95": 20.12079939999012,
    "max": 61.466523999996525
  },
  "scheduling_lateness_ms": {
    "p50": 0.10569248559022526,
    "p95": 0.24410824297405043,
    "max": 117.01358899992442
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 5.051,
      "p95": 6.0855,
      "max": 7.32
    },
    "policy": {
      "p50": 3.45,
      "p95": 4.8065,
      "max": 7.243
    },
    "observation_to_motor": {
      "p50": 8.713,
      "p95": 11.038,
      "max": 13.088
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1440.0,
      "controller": 344.7734375,
      "publisher": 99.93359375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1873.45703125,
    "min_wsl_available_mib": 5619.49609375,
    "nvml_gpu_peak_mib": 1538,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
