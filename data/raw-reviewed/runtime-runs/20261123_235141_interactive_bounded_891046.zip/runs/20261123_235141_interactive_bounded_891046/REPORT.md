# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_235141_interactive_bounded_891046",
  "active_seconds": 146.12353811100002,
  "published_frames": 7268,
  "debug_samples": 7306,
  "physics_samples": 3315,
  "fall_count": 0,
  "publish_hz": 49.73886645326757,
  "debug_hz": 49.99974072447932,
  "realtime_factor": 0.45379016603238087,
  "spring_disabled": true,
  "base_height_min_m": 0.7610868185632383,
  "base_height_max_m": 0.7704824229351595,
  "actual_base_displacement_m": 0.10806586993641534,
  "actual_base_path_length_m": 0.11572731185367077,
  "tracking_rmse_rad": 0.42937664502418527,
  "left_arm_tracking_rmse_rad": 0.15029825628698223,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2400873687409261e-08,
    "p95": 1.491519165569424e-08,
    "max": 1.8952723637132984e-08
  },
  "target_observation_lag_ms": {
    "p50": 55.61080750000258,
    "p95": 56.548517199996695,
    "max": 68.93588900001646
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.009468451142311096,
  "left_arm_reference_speed_max_rad_s": 1.1330195668136183,
  "left_arm_reference_accel_max_rad_s2": 265.38347457091317,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7054840000080276,
    "p95": 0.9056506999982615,
    "max": 63.149955999989515
  },
  "physics_sample_gap_ms": {
    "p50": 40.410831000002645,
    "p95": 89.33653800000619,
    "max": 178.87776700001723
  },
  "feedback_sample_gap_ms": {
    "p50": 19.992343000012625,
    "p95": 20.994609999996783,
    "max": 35.10108700004366
  },
  "publish_interval_ms": {
    "p50": 20.000132000006943,
    "p95": 20.051997300018343,
    "max": 66.64028899999153
  },
  "scheduling_lateness_ms": {
    "p50": 0.08298198132195012,
    "p95": 0.1343979848201115,
    "max": 120.71868699996458
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.8004999999999995,
      "p95": 5.0059,
      "max": 5.941
    },
    "policy": {
      "p50": 3.685,
      "p95": 3.88735,
      "max": 4.106
    },
    "observation_to_motor": {
      "p50": 8.476500000000001,
      "p95": 8.796149999999999,
      "max": 9.449
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1440.8671875,
      "controller": 357.18359375,
      "publisher": 94.8515625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1884.265625,
    "min_wsl_available_mib": 5604.62890625,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
