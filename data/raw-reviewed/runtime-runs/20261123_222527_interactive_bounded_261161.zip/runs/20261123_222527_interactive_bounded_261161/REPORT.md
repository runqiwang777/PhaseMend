# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_222527_interactive_bounded_261161",
  "active_seconds": 30.48752356,
  "published_frames": 1504,
  "debug_samples": 1524,
  "physics_samples": 701,
  "fall_count": 0,
  "publish_hz": 49.332829690941075,
  "debug_hz": 49.99390087703801,
  "realtime_factor": 0.45971236613198424,
  "spring_disabled": true,
  "base_height_min_m": 0.7674910974407675,
  "base_height_max_m": 0.7872644480527474,
  "actual_base_displacement_m": 0.12040770907532063,
  "actual_base_path_length_m": 0.3275155461252275,
  "tracking_rmse_rad": 0.2264529317263942,
  "left_arm_tracking_rmse_rad": 0.19330491298212996,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.3015088796940692e-08,
    "p95": 1.656117091518331e-08,
    "max": 1.8865082788042668e-08
  },
  "target_observation_lag_ms": {
    "p50": 103.73842549999779,
    "p95": 106.0661119999935,
    "max": 110.92597499998647
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.08042958378791809,
  "left_arm_reference_speed_max_rad_s": 1.0726996537765943,
  "left_arm_reference_accel_max_rad_s2": 212.72439559270194,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.7351735000042936,
    "p95": 19.257247999998118,
    "max": 51.85058899999717
  },
  "physics_sample_gap_ms": {
    "p50": 40.68904800000439,
    "p95": 84.71153745002054,
    "max": 178.54697699999633
  },
  "feedback_sample_gap_ms": {
    "p50": 19.998587000003454,
    "p95": 22.353001100012193,
    "max": 27.643053999980793
  },
  "publish_interval_ms": {
    "p50": 20.001465999996526,
    "p95": 21.921110499999926,
    "max": 54.637888999991446
  },
  "scheduling_lateness_ms": {
    "p50": 0.10782098878792112,
    "p95": 12.161665299957564,
    "max": 106.09795199982841
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.833500000000001,
      "p95": 5.017,
      "max": 5.367
    },
    "policy": {
      "p50": 3.6879999999999997,
      "p95": 3.7904999999999998,
      "max": 3.851
    },
    "observation_to_motor": {
      "p50": 8.523,
      "p95": 8.75035,
      "max": 9.039
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1442.0078125,
      "controller": 343.5546875,
      "publisher": 98.984375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1874.859375,
    "min_wsl_available_mib": 5618.66796875,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
