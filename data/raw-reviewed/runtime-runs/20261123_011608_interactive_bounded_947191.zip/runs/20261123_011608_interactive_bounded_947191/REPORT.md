# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_011608_interactive_bounded_947191",
  "active_seconds": 17.440176624000003,
  "published_frames": 872,
  "debug_samples": 872,
  "physics_samples": 872,
  "fall_count": 0,
  "publish_hz": 50.00142275575339,
  "debug_hz": 50.000666108185115,
  "realtime_factor": 0.999993554519668,
  "spring_disabled": true,
  "base_height_min_m": 0.757107433375919,
  "base_height_max_m": 0.7760907390447717,
  "actual_base_displacement_m": 0.0022541294493771177,
  "actual_base_path_length_m": 0.1543083202743695,
  "tracking_rmse_rad": 0.12849834739770402,
  "left_arm_tracking_rmse_rad": 0.17281170765298326,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.228713723348397e-08,
    "p95": 1.58621482332685e-08,
    "max": 0.00024181479527562728
  },
  "target_observation_lag_ms": {
    "p50": 83.69610099998681,
    "p95": 90.44877499997597,
    "max": 126.46867799998063
  },
  "max_reference_edit_rad": 0.8649772677696101,
  "left_shoulder_actual_range_rad": 0.12133482098579401,
  "left_arm_reference_speed_max_rad_s": 0.4857183542060828,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000023,
  "intervention_selected_speed_max_rad_s": 1.0675919553116406,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 1.9263030000047365,
    "p95": 3.2235358000207266,
    "max": 7.004058000006808
  },
  "physics_sample_gap_ms": {
    "p50": 20.011632999967333,
    "p95": 20.792004500009398,
    "max": 66.16907900001934
  },
  "feedback_sample_gap_ms": {
    "p50": 19.899180999971122,
    "p95": 24.221163499987597,
    "max": 29.32615600002464
  },
  "publish_interval_ms": {
    "p50": 19.999657000028037,
    "p95": 20.105595000018184,
    "max": 49.09224400000767
  },
  "scheduling_lateness_ms": {
    "p50": 0.11858851340207366,
    "p95": 0.2233928590612775,
    "max": 29.351941008542326
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.756,
      "p95": 4.8989,
      "max": 4.965
    },
    "policy": {
      "p50": 3.705,
      "p95": 3.8401,
      "max": 3.88
    },
    "observation_to_motor": {
      "p50": 8.448,
      "p95": 8.6547,
      "max": 8.824
    }
  },
  "http_command_queue_ms": {
    "p50": 6.059559999982866,
    "p95": 16.923933599969136,
    "max": 27.50766100001556
  },
  "http_to_reference_publish_ms": {
    "p50": 8.967439999992166,
    "p95": 20.126540199999,
    "max": 30.374693999988267
  },
  "takeover_seams": [
    {
      "t": 309.043900929,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.046875,
      "controller": 341.96484375,
      "publisher": 114.90234375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1877.9296875,
    "min_wsl_available_mib": 5609.12890625,
    "nvml_gpu_peak_mib": 1290,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
