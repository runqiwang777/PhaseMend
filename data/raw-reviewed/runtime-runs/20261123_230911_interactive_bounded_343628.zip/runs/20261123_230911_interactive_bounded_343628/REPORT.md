# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "failed",
  "error": "sim exited (0); see /mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_230911_interactive_bounded_343628/sim.log",
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_230911_interactive_bounded_343628",
  "active_seconds": 0.02692892900000743,
  "published_frames": 1,
  "debug_samples": 0,
  "physics_samples": 0,
  "fall_count": 0,
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.84375,
      "controller": 339.42578125,
      "publisher": 98.046875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1875.546875,
    "min_wsl_available_mib": 5623.484375,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
