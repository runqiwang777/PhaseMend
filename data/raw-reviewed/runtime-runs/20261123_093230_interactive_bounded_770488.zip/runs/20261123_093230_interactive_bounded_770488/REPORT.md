# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_093230_interactive_bounded_770488",
  "active_seconds": 38.10810304499998,
  "published_frames": 1861,
  "debug_samples": 1905,
  "physics_samples": 1906,
  "fall_count": 0,
  "publish_hz": 48.83506566550326,
  "debug_hz": 49.99874218894301,
  "realtime_factor": 1.000014965709257,
  "spring_disabled": true,
  "base_height_min_m": 0.7555648226009455,
  "base_height_max_m": 0.777413478545685,
  "actual_base_displacement_m": 0.021399329539727698,
  "actual_base_path_length_m": 0.28878189180818953,
  "tracking_rmse_rad": 0.12211692861466109,
  "left_arm_tracking_rmse_rad": 0.1789217344583804,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.1990569462595632e-08,
    "p95": 1.543202158776741e-08,
    "max": 1.718991271053626e-08
  },
  "target_observation_lag_ms": {
    "p50": 244.05480500001886,
    "p95": 246.46692259999554,
    "max": 249.4231170000205
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.22249428927898407,
  "left_arm_reference_speed_max_rad_s": 0.5270455402472563,
  "left_arm_reference_accel_max_rad_s2": 115.69804092527747,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.725271999982624,
    "p95": 0.9426430000019081,
    "max": 79.26765199999863
  },
  "physics_sample_gap_ms": {
    "p50": 19.996738000003234,
    "p95": 20.87567960000456,
    "max": 81.87920000000304
  },
  "feedback_sample_gap_ms": {
    "p50": 20.009342500003413,
    "p95": 22.263772499984213,
    "max": 26.35536200000388
  },
  "publish_interval_ms": {
    "p50": 20.0002594999944,
    "p95": 20.07667385001497,
    "max": 82.60520899997914
  },
  "scheduling_lateness_ms": {
    "p50": 0.0944039980481648,
    "p95": 0.19649398231535997,
    "max": 119.63506999993001
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.768,
      "p95": 4.944800000000001,
      "max": 5.021
    },
    "policy": {
      "p50": 3.754,
      "p95": 3.8688,
      "max": 3.881
    },
    "observation_to_motor": {
      "p50": 8.515,
      "p95": 8.745800000000001,
      "max": 8.897
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1421.58984375,
      "controller": 343.54296875,
      "publisher": 105.52734375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1865.34765625,
    "min_wsl_available_mib": 5627.34375,
    "nvml_gpu_peak_mib": 1212,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
