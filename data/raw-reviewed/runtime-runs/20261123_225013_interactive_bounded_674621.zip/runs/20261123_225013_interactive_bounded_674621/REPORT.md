# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_225013_interactive_bounded_674621",
  "active_seconds": 71.411039811,
  "published_frames": 3519,
  "debug_samples": 3571,
  "physics_samples": 921,
  "fall_count": 0,
  "publish_hz": 49.27845783897343,
  "debug_hz": 49.9994069496113,
  "realtime_factor": 0.25772847392329035,
  "spring_disabled": true,
  "base_height_min_m": 0.7660501032543388,
  "base_height_max_m": 0.7930768664964669,
  "actual_base_displacement_m": 0.12985504958568128,
  "actual_base_path_length_m": 0.4061160087041411,
  "tracking_rmse_rad": 0.27208581740851023,
  "left_arm_tracking_rmse_rad": 0.1676562050114743,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.2400873687409261e-08,
    "p95": 1.5973199657980078e-08,
    "max": 1.8952723637132984e-08
  },
  "target_observation_lag_ms": {
    "p50": 152.6943220000021,
    "p95": 154.23607049998935,
    "max": 159.57728400002225
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.11163561046123499,
  "left_arm_reference_speed_max_rad_s": 0.3329541224348153,
  "left_arm_reference_accel_max_rad_s2": 41.31707649337986,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.9237769999970169,
    "p95": 1.4009467999926526,
    "max": 52.66318200000342
  },
  "physics_sample_gap_ms": {
    "p50": 70.95204000000876,
    "p95": 160.63332775000558,
    "max": 241.50023300001067
  },
  "feedback_sample_gap_ms": {
    "p50": 19.9938054999933,
    "p95": 21.1784989000094,
    "max": 26.096004000009998
  },
  "publish_interval_ms": {
    "p50": 20.001230499985923,
    "p95": 20.085205149995033,
    "max": 186.92193400002566
  },
  "scheduling_lateness_ms": {
    "p50": 0.11132397264645988,
    "p95": 0.1806091860487413,
    "max": 167.01773199594072
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.793,
      "p95": 5.0602,
      "max": 5.168
    },
    "policy": {
      "p50": 3.711,
      "p95": 3.9248,
      "max": 4.104
    },
    "observation_to_motor": {
      "p50": 8.498,
      "p95": 8.9067,
      "max": 9.046
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": false,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1441.234375,
      "controller": 347.375,
      "publisher": 105.0390625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1879.5859375,
    "min_wsl_available_mib": 5575.4609375,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
