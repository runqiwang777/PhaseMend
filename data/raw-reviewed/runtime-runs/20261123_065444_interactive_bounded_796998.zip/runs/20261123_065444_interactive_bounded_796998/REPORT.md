# 本次真实仿真运行

- 实验判定：未通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/mnt/d/Github/PhaseMend/sonic_takeover_wsl/takeover/runs/20261123_065444_interactive_bounded_796998",
  "active_seconds": 38.07696435,
  "published_frames": 1871,
  "debug_samples": 1904,
  "physics_samples": 1904,
  "fall_count": 0,
  "publish_hz": 49.13760361634977,
  "debug_hz": 49.99845580701947,
  "realtime_factor": 1.0000132761875384,
  "spring_disabled": true,
  "base_height_min_m": 0.7459200236396971,
  "base_height_max_m": 0.7769392420045842,
  "actual_base_displacement_m": 0.016103875441085814,
  "actual_base_path_length_m": 0.3187608631257657,
  "tracking_rmse_rad": 0.14354365209354583,
  "left_arm_tracking_rmse_rad": 0.20049271024024504,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.203443750246705e-08,
    "p95": 1.57083886478781e-08,
    "max": 1.820960881696595e-08
  },
  "target_observation_lag_ms": {
    "p50": 86.65683449999051,
    "p95": 87.5902500500132,
    "max": 93.52557200003275
  },
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.2006578240543604,
  "left_arm_reference_speed_max_rad_s": 0.6231025705001075,
  "left_arm_reference_accel_max_rad_s2": 110.36333558116064,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.735857999984546,
    "p95": 1.41315600001235,
    "max": 39.45607500000392
  },
  "physics_sample_gap_ms": {
    "p50": 19.99569499997733,
    "p95": 20.96184580003637,
    "max": 61.56861300001992
  },
  "feedback_sample_gap_ms": {
    "p50": 19.99167200000329,
    "p95": 21.055034900007286,
    "max": 26.143468000043413
  },
  "publish_interval_ms": {
    "p50": 20.00057450001691,
    "p95": 20.161284400006707,
    "max": 47.12908900000912
  },
  "scheduling_lateness_ms": {
    "p50": 0.08155900133033356,
    "p95": 0.26495050704511414,
    "max": 119.06329599992205
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.797,
      "p95": 4.932449999999999,
      "max": 4.965
    },
    "policy": {
      "p50": 3.307,
      "p95": 3.79565,
      "max": 3.836
    },
    "observation_to_motor": {
      "p50": 8.1725,
      "p95": 8.6103,
      "max": 8.709
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "actual_robot_translation": false
  },
  "verified": false,
  "resources": {
    "max_rss_mib": {
      "sim": 1421.50390625,
      "controller": 343.74609375,
      "publisher": 98.4140625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1858.6640625,
    "min_wsl_available_mib": 5584.25390625,
    "nvml_gpu_peak_mib": 1221,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
