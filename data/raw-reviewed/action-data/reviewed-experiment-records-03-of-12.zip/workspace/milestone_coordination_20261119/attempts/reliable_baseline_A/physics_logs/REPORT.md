# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_191817_interactive_bounded_406182",
  "active_seconds": 16.520113718000005,
  "published_frames": 826,
  "debug_samples": 817,
  "physics_samples": 826,
  "fall_count": 0,
  "publish_hz": 50.000004884848806,
  "debug_hz": 49.459067826843956,
  "realtime_factor": 1.0000494857219528,
  "spring_disabled": true,
  "base_height_min_m": 0.7857470196821262,
  "base_height_max_m": 0.7872871289486053,
  "actual_base_displacement_m": 0.004928441722343775,
  "actual_base_path_length_m": 0.1178521373607181,
  "tracking_rmse_rad": 0.11364735338147723,
  "left_arm_tracking_rmse_rad": 0.20473455323107279,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 8.061783669645089e-09,
    "p95": 1.081991349650829e-08,
    "max": 1.27718761712051e-08
  },
  "target_observation_lag_ms": {
    "p50": 722.9767800000388,
    "p95": 730.9073219500135,
    "max": 747.1030359999986
  },
  "max_reference_edit_rad": 0.6028426733062303,
  "left_shoulder_actual_range_rad": 0.09137537330389023,
  "left_arm_reference_speed_max_rad_s": 1.2578586444035256,
  "left_arm_reference_accel_max_rad_s2": 8.000000000000021,
  "intervention_selected_speed_max_rad_s": 1.2578586444035256,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 2.1102505000101246,
    "p95": 3.1540449999880593,
    "max": 9.569472000009682
  },
  "physics_sample_gap_ms": {
    "p50": 20.003930000029868,
    "p95": 20.957614799999646,
    "max": 23.82162399999288
  },
  "feedback_sample_gap_ms": {
    "p50": 19.995173999973304,
    "p95": 21.956016750010576,
    "max": 109.97037200002069
  },
  "publish_interval_ms": {
    "p50": 19.999143000006825,
    "p95": 20.061619800026165,
    "max": 22.082685999976093
  },
  "scheduling_lateness_ms": {
    "p50": 0.1112595130337013,
    "p95": 0.1611995074739525,
    "max": 2.229029000261562
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 1.7850000000000001,
      "p95": 4.7483999999999975,
      "max": 5.604
    },
    "policy": {
      "p50": 1.5765,
      "p95": 3.6326999999999976,
      "max": 4.65
    },
    "observation_to_motor": {
      "p50": 3.4215,
      "p95": 8.268599999999994,
      "max": 10.168
    }
  },
  "http_command_queue_ms": {
    "p50": 12.312403000009908,
    "p95": 15.505759999996371,
    "max": 19.58523400003287
  },
  "http_to_reference_publish_ms": {
    "p50": 15.160419999972419,
    "p95": 18.454336999980114,
    "max": 25.915831000020262
  },
  "takeover_seams": [
    {
      "t": 322.387722873,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1424.4140625,
      "controller": 360.125,
      "publisher": 107.15234375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1889.50390625,
    "min_wsl_available_mib": 4888.30859375,
    "nvml_gpu_peak_mib": 1150,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
