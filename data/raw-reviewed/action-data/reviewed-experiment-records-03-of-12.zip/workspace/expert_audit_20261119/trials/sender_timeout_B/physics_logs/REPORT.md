# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_094950_interactive_bounded_017937",
  "active_seconds": 4.260117342000001,
  "published_frames": 213,
  "debug_samples": 212,
  "physics_samples": 213,
  "fall_count": 0,
  "publish_hz": 49.99947245839674,
  "debug_hz": 49.80409051154461,
  "realtime_factor": 1.0000976706240365,
  "spring_disabled": true,
  "base_height_min_m": 0.7858377244994977,
  "base_height_max_m": 0.788763439758753,
  "actual_base_displacement_m": 0.015775127883408024,
  "actual_base_path_length_m": 0.030933629557949954,
  "tracking_rmse_rad": 0.10616626217731118,
  "left_arm_tracking_rmse_rad": 0.15282074360419995,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.3547659628398315e-08,
    "p95": 1.3547659628398315e-08,
    "max": 1.382206568800965e-08
  },
  "target_observation_lag_ms": {
    "p50": 754.970974999992,
    "p95": 771.1252664000199,
    "max": 772.510785999998
  },
  "max_reference_edit_rad": 0.5754695636426429,
  "left_shoulder_actual_range_rad": 0.028273865580558777,
  "left_arm_reference_speed_max_rad_s": 0.8467955500533919,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000023,
  "intervention_selected_speed_max_rad_s": 1.4765033314509068,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 0.6258849999767335,
    "p95": 2.5907830000051026,
    "max": 5.415555999945809
  },
  "physics_sample_gap_ms": {
    "p50": 20.006511999980603,
    "p95": 20.650475250025124,
    "max": 21.079791999966346
  },
  "feedback_sample_gap_ms": {
    "p50": 19.958271000007244,
    "p95": 25.98463000001061,
    "max": 43.08155500001476
  },
  "publish_interval_ms": {
    "p50": 19.999834999993027,
    "p95": 20.045931049980936,
    "max": 20.35379900001999
  },
  "scheduling_lateness_ms": {
    "p50": 0.0769790003118942,
    "p95": 0.12409260277763666,
    "max": 0.43398000275374216
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 3.005,
      "p95": 6.4495,
      "max": 6.541
    },
    "policy": {
      "p50": 1.7610000000000001,
      "p95": 3.7672499999999998,
      "max": 3.807
    },
    "observation_to_motor": {
      "p50": 4.846,
      "p95": 8.342,
      "max": 8.477
    }
  },
  "http_command_queue_ms": {
    "p50": 7.315580000010868,
    "p95": 18.464171999994505,
    "max": 18.64972199996373
  },
  "http_to_reference_publish_ms": {
    "p50": 9.662287999958608,
    "p95": 20.856638999987354,
    "max": 22.2103529999913
  },
  "takeover_seams": [
    {
      "t": 483.851172091,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.51953125,
      "controller": 361.80859375,
      "publisher": 98.9140625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1884.2421875,
    "min_wsl_available_mib": 4936.41796875,
    "nvml_gpu_peak_mib": 1219,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
