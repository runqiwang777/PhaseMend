# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_094551_interactive_bounded_237048",
  "active_seconds": 16.540124510000027,
  "published_frames": 827,
  "debug_samples": 821,
  "physics_samples": 827,
  "fall_count": 0,
  "publish_hz": 49.99983578746423,
  "debug_hz": 49.64187399821264,
  "realtime_factor": 1.0000004968530578,
  "spring_disabled": true,
  "base_height_min_m": 0.7853464250876238,
  "base_height_max_m": 0.7869671162091706,
  "actual_base_displacement_m": 0.0017454740407319386,
  "actual_base_path_length_m": 0.11362274813027778,
  "tracking_rmse_rad": 0.10976929682089487,
  "left_arm_tracking_rmse_rad": 0.18746789137947026,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 8.322558406340281e-09,
    "p95": 1.3547659628398315e-08,
    "max": 1.5472821267256985e-08
  },
  "target_observation_lag_ms": {
    "p50": 795.6827239999882,
    "p95": 832.6672270000131,
    "max": 858.9857229999893
  },
  "max_reference_edit_rad": 0.7032069131406631,
  "left_shoulder_actual_range_rad": 0.10060925781726837,
  "left_arm_reference_speed_max_rad_s": 1.4128321049075632,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000023,
  "intervention_selected_speed_max_rad_s": 1.4128321049075632,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 1.9297230000177024,
    "p95": 3.2485589999964746,
    "max": 8.141563000009455
  },
  "physics_sample_gap_ms": {
    "p50": 20.00157150001769,
    "p95": 20.34653424999533,
    "max": 21.765423000005057
  },
  "feedback_sample_gap_ms": {
    "p50": 20.08294899998475,
    "p95": 25.036242000007288,
    "max": 56.84530999999993
  },
  "publish_interval_ms": {
    "p50": 19.9999440000056,
    "p95": 20.034272250001095,
    "max": 21.723710999992818
  },
  "scheduling_lateness_ms": {
    "p50": 0.07561799321820217,
    "p95": 0.1117928977606652,
    "max": 1.795961998425355
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.533,
      "p95": 4.7918,
      "max": 10.855
    },
    "policy": {
      "p50": 1.912,
      "p95": 6.5600499999999995,
      "max": 44.851
    },
    "observation_to_motor": {
      "p50": 4.371499999999999,
      "p95": 9.834,
      "max": 55.707
    }
  },
  "http_command_queue_ms": {
    "p50": 6.313960499994664,
    "p95": 17.380294700014076,
    "max": 19.36616599999752
  },
  "http_to_reference_publish_ms": {
    "p50": 8.821767000000591,
    "p95": 20.02769714998891,
    "max": 24.47280900000237
  },
  "takeover_seams": [
    {
      "t": 244.808287591,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.7265625,
      "controller": 363.2734375,
      "publisher": 99.015625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1886.015625,
    "min_wsl_available_mib": 4932.515625,
    "nvml_gpu_peak_mib": 1249,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
