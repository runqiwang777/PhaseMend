# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_094859_interactive_bounded_261330",
  "active_seconds": 8.140208035,
  "published_frames": 407,
  "debug_samples": 404,
  "physics_samples": 407,
  "fall_count": 0,
  "publish_hz": 49.99965249009984,
  "debug_hz": 49.66586482216534,
  "realtime_factor": 1.0000301213511267,
  "spring_disabled": true,
  "base_height_min_m": 0.7858682300072545,
  "base_height_max_m": 0.7863186786225624,
  "actual_base_displacement_m": 0.004720319596126252,
  "actual_base_path_length_m": 0.02742414751474616,
  "tracking_rmse_rad": 0.10440727826512061,
  "left_arm_tracking_rmse_rad": 0.17337742655385466,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 8.375946457196392e-09,
    "p95": 1.3547659628398315e-08,
    "max": 0.0018055602097239404
  },
  "target_observation_lag_ms": {
    "p50": 659.4222935000005,
    "p95": 679.7338799999721,
    "max": 1823.5663469999963
  },
  "max_reference_edit_rad": 0.7093925945032284,
  "left_shoulder_actual_range_rad": 0.06815826892852783,
  "left_arm_reference_speed_max_rad_s": 1.1173152190414593,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000023,
  "intervention_selected_speed_max_rad_s": 1.5000000000000013,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 2.0469390000243948,
    "p95": 4.037977600012255,
    "max": 8.361787000012555
  },
  "physics_sample_gap_ms": {
    "p50": 20.003666500002737,
    "p95": 20.31023249998043,
    "max": 24.299116999998205
  },
  "feedback_sample_gap_ms": {
    "p50": 20.02107700002398,
    "p95": 31.749482999992996,
    "max": 81.53559499999119
  },
  "publish_interval_ms": {
    "p50": 20.000565999993114,
    "p95": 20.136095499978524,
    "max": 20.698213000002852
  },
  "scheduling_lateness_ms": {
    "p50": 0.08465300260240838,
    "p95": 0.22620170323648375,
    "max": 0.796522004407052
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.588,
      "p95": 3.2794999999999948,
      "max": 5.39
    },
    "policy": {
      "p50": 1.606,
      "p95": 2.4322999999999944,
      "max": 4.757
    },
    "observation_to_motor": {
      "p50": 4.195,
      "p95": 5.642599999999989,
      "max": 10.148
    }
  },
  "http_command_queue_ms": {
    "p50": 5.134399500008158,
    "p95": 18.86560485002917,
    "max": 19.341851999968185
  },
  "http_to_reference_publish_ms": {
    "p50": 8.269399499994279,
    "p95": 22.073442899989004,
    "max": 27.32594799999788
  },
  "takeover_seams": [
    {
      "t": 432.237325646,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.5390625,
      "controller": 362.1953125,
      "publisher": 98.51171875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1884.24609375,
    "min_wsl_available_mib": 4932.1640625,
    "nvml_gpu_peak_mib": 1195,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
