# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_094343_interactive_bounded_183303",
  "active_seconds": 16.520129519999983,
  "published_frames": 826,
  "debug_samples": 823,
  "physics_samples": 826,
  "fall_count": 0,
  "publish_hz": 49.99986890640435,
  "debug_hz": 49.81726237267212,
  "realtime_factor": 1.0000382598279056,
  "spring_disabled": true,
  "base_height_min_m": 0.785729177756805,
  "base_height_max_m": 0.7871492341973199,
  "actual_base_displacement_m": 0.006379804903398496,
  "actual_base_path_length_m": 0.09773419739017594,
  "tracking_rmse_rad": 0.11928483231238421,
  "left_arm_tracking_rmse_rad": 0.217512356904131,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 8.07053102367645e-09,
    "p95": 1.081991349650829e-08,
    "max": 1.2961528369246122e-08
  },
  "target_observation_lag_ms": {
    "p50": 609.7024310000023,
    "p95": 619.7390012499859,
    "max": 668.2011910000085
  },
  "max_reference_edit_rad": 0.6023855706833158,
  "left_shoulder_actual_range_rad": 0.09029089659452438,
  "left_arm_reference_speed_max_rad_s": 1.2578586444035977,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000009,
  "intervention_selected_speed_max_rad_s": 1.2578586444035977,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 2.682199999995305,
    "p95": 5.022573000001529,
    "max": 13.714242999995463
  },
  "physics_sample_gap_ms": {
    "p50": 20.002227999995625,
    "p95": 20.735112599984973,
    "max": 27.723992999995062
  },
  "feedback_sample_gap_ms": {
    "p50": 20.027705500005766,
    "p95": 24.282499399996023,
    "max": 60.354199000016706
  },
  "publish_interval_ms": {
    "p50": 19.998661999991896,
    "p95": 20.100950800002693,
    "max": 21.940534000009393
  },
  "scheduling_lateness_ms": {
    "p50": 0.09534600201988042,
    "p95": 0.22353600161650888,
    "max": 2.0713750019325516
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 1.388,
      "p95": 8.3829,
      "max": 20.07
    },
    "policy": {
      "p50": 1.83,
      "p95": 3.2098,
      "max": 5.244
    },
    "observation_to_motor": {
      "p50": 4.094,
      "p95": 10.37,
      "max": 23.359
    }
  },
  "http_command_queue_ms": {
    "p50": 8.250785999997845,
    "p95": 17.334128650003322,
    "max": 19.708248000000594
  },
  "http_to_reference_publish_ms": {
    "p50": 11.988234999996905,
    "p95": 21.206346300009926,
    "max": 24.65065000001232
  },
  "takeover_seams": [
    {
      "t": 118.203837815,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.24609375,
      "controller": 359.703125,
      "publisher": 98.1875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1881.13671875,
    "min_wsl_available_mib": 4933.609375,
    "nvml_gpu_peak_mib": 1336,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
