# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_151149_interactive_bounded_388838",
  "active_seconds": 16.740139818999992,
  "published_frames": 837,
  "debug_samples": 837,
  "physics_samples": 837,
  "fall_count": 0,
  "publish_hz": 50.00009969218439,
  "debug_hz": 50.01461907872187,
  "realtime_factor": 1.000028835281721,
  "spring_disabled": true,
  "base_height_min_m": 0.7856149767299302,
  "base_height_max_m": 0.7871469596962251,
  "actual_base_displacement_m": 0.0021351443733356183,
  "actual_base_path_length_m": 0.1180981539710966,
  "tracking_rmse_rad": 0.11755652474070606,
  "left_arm_tracking_rmse_rad": 0.21415315087891507,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 8.18626685526095e-09,
    "p95": 1.081991349650829e-08,
    "max": 1.351489695484974e-08
  },
  "target_observation_lag_ms": {
    "p50": 321.0245190000194,
    "p95": 323.8958864999901,
    "max": 360.063021000002
  },
  "max_reference_edit_rad": 0.6000682807659341,
  "left_shoulder_actual_range_rad": 0.09478051960468292,
  "left_arm_reference_speed_max_rad_s": 1.254428195437124,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000009,
  "intervention_selected_speed_max_rad_s": 1.254428195437124,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 2.374174999999923,
    "p95": 4.439701999990572,
    "max": 11.705403999997088
  },
  "physics_sample_gap_ms": {
    "p50": 19.999571999996135,
    "p95": 20.664393499984612,
    "max": 24.06223799999907
  },
  "feedback_sample_gap_ms": {
    "p50": 20.01369299999567,
    "p95": 22.71343324999009,
    "max": 29.43335200001229
  },
  "publish_interval_ms": {
    "p50": 20.000710999994453,
    "p95": 20.083896499990317,
    "max": 20.527918999988515
  },
  "scheduling_lateness_ms": {
    "p50": 0.11270899858573102,
    "p95": 0.19779259601477844,
    "max": 0.6157180004322527
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 4.8385,
      "p95": 5.1815999999999995,
      "max": 5.266
    },
    "policy": {
      "p50": 3.6885,
      "p95": 3.88835,
      "max": 4.043
    },
    "observation_to_motor": {
      "p50": 8.565000000000001,
      "p95": 8.97325,
      "max": 9.182
    }
  },
  "http_command_queue_ms": {
    "p50": 8.465347000026213,
    "p95": 17.66115309999634,
    "max": 19.48520000000542
  },
  "http_to_reference_publish_ms": {
    "p50": 11.912727999998651,
    "p95": 20.956573199997308,
    "max": 26.307201000008718
  },
  "takeover_seams": [
    {
      "t": 124.037669538,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.55078125,
      "controller": 359.1640625,
      "publisher": 106.9375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1887.62109375,
    "min_wsl_available_mib": 4894.83203125,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
