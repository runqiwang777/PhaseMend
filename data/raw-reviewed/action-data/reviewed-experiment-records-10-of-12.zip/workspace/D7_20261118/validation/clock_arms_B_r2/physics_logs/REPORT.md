# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_000020_interactive_bounded_335601",
  "active_seconds": 16.760108950000017,
  "published_frames": 838,
  "debug_samples": 839,
  "physics_samples": 838,
  "fall_count": 0,
  "publish_hz": 49.99974142308159,
  "debug_hz": 50.04288676889033,
  "realtime_factor": 1.0000057840841465,
  "spring_disabled": true,
  "base_height_min_m": 0.7852411965055094,
  "base_height_max_m": 0.7867559795311346,
  "actual_base_displacement_m": 0.0005037908211641057,
  "actual_base_path_length_m": 0.1308120698786692,
  "tracking_rmse_rad": 0.10966635004056959,
  "left_arm_tracking_rmse_rad": 0.18611513458992557,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 8.332860226623363e-09,
    "p95": 1.3547659628398315e-08,
    "max": 0.0006970909330498284
  },
  "target_observation_lag_ms": {
    "p50": 391.72058299999435,
    "p95": 399.07410939998726,
    "max": 435.4451689999905
  },
  "max_reference_edit_rad": 0.7066092332436639,
  "left_shoulder_actual_range_rad": 0.10137532651424408,
  "left_arm_reference_speed_max_rad_s": 1.2946113820655802,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000023,
  "intervention_selected_speed_max_rad_s": 1.5000000000000013,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 2.0084924999821396,
    "p95": 4.195747700021,
    "max": 5.80563500000153
  },
  "physics_sample_gap_ms": {
    "p50": 19.996176999995896,
    "p95": 20.399431800001366,
    "max": 21.598394000022836
  },
  "feedback_sample_gap_ms": {
    "p50": 20.009975999983,
    "p95": 32.701800199996,
    "max": 60.12978199998997
  },
  "publish_interval_ms": {
    "p50": 19.999519999998938,
    "p95": 20.061963600016952,
    "max": 22.249647999956323
  },
  "scheduling_lateness_ms": {
    "p50": 0.08675750262909787,
    "p95": 0.15118890890732922,
    "max": 2.3320260107766444
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.6055,
      "p95": 9.203699999999998,
      "max": 11.353
    },
    "policy": {
      "p50": 2.121,
      "p95": 4.4711,
      "max": 5.714
    },
    "observation_to_motor": {
      "p50": 4.731,
      "p95": 12.927899999999998,
      "max": 15.023
    }
  },
  "http_command_queue_ms": {
    "p50": 4.399819000013849,
    "p95": 17.76907949997053,
    "max": 19.460057000003417
  },
  "http_to_reference_publish_ms": {
    "p50": 7.191713000054278,
    "p95": 20.75295150001466,
    "max": 24.06264299997929
  },
  "takeover_seams": [
    {
      "t": 342.322610397,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1424.62109375,
      "controller": 363.39453125,
      "publisher": 107.5859375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1892.4765625,
    "min_wsl_available_mib": 4914.6328125,
    "nvml_gpu_peak_mib": 1082,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
