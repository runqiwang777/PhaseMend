# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261118_235819_interactive_bounded_462458",
  "active_seconds": 16.640133909000014,
  "published_frames": 832,
  "debug_samples": 832,
  "physics_samples": 832,
  "fall_count": 0,
  "publish_hz": 49.99985199502291,
  "debug_hz": 49.99207358828759,
  "realtime_factor": 1.0000033880986325,
  "spring_disabled": true,
  "base_height_min_m": 0.7854816165018423,
  "base_height_max_m": 0.7869696469183887,
  "actual_base_displacement_m": 0.004113334243749289,
  "actual_base_path_length_m": 0.11831570329319276,
  "tracking_rmse_rad": 0.11000549299536105,
  "left_arm_tracking_rmse_rad": 0.18686742332694806,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 8.591306941193056e-09,
    "p95": 1.3547659628398315e-08,
    "max": 0.0007930614099935659
  },
  "target_observation_lag_ms": {
    "p50": 592.3807800000134,
    "p95": 599.9792190999784,
    "max": 615.7615519999808
  },
  "max_reference_edit_rad": 0.7022003665657655,
  "left_shoulder_actual_range_rad": 0.10050708055496216,
  "left_arm_reference_speed_max_rad_s": 1.366853665272716,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000023,
  "intervention_selected_speed_max_rad_s": 1.3867568055951796,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 2.007638999998562,
    "p95": 3.6184652000045476,
    "max": 6.081547999997383
  },
  "physics_sample_gap_ms": {
    "p50": 20.001554000003807,
    "p95": 20.45595599999217,
    "max": 24.972436000012976
  },
  "feedback_sample_gap_ms": {
    "p50": 20.13704199998756,
    "p95": 26.721366499984356,
    "max": 43.0270419999772
  },
  "publish_interval_ms": {
    "p50": 20.00036299997987,
    "p95": 20.079524500005164,
    "max": 23.09288600000059
  },
  "scheduling_lateness_ms": {
    "p50": 0.08094399603919555,
    "p95": 0.1619761934080088,
    "max": 3.1696589942669107
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.5860000000000003,
      "p95": 5.977599999999998,
      "max": 8.267
    },
    "policy": {
      "p50": 1.9285,
      "p95": 2.392,
      "max": 3.659
    },
    "observation_to_motor": {
      "p50": 4.484500000000001,
      "p95": 8.6607,
      "max": 10.32
    }
  },
  "http_command_queue_ms": {
    "p50": 7.376350000001253,
    "p95": 17.856073849999632,
    "max": 19.42686600000343
  },
  "http_to_reference_publish_ms": {
    "p50": 10.137859500005675,
    "p95": 20.707000049996793,
    "max": 22.695700000014085
  },
  "takeover_seams": [
    {
      "t": 221.519364826,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.7890625,
      "controller": 363.80859375,
      "publisher": 107.79296875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1892.265625,
    "min_wsl_available_mib": 4932.4921875,
    "nvml_gpu_peak_mib": 1250,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
