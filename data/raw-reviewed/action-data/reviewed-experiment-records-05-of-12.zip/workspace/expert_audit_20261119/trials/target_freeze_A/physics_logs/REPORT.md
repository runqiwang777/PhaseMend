# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_094651_interactive_bounded_090797",
  "active_seconds": 4.1403516999999965,
  "published_frames": 207,
  "debug_samples": 207,
  "physics_samples": 207,
  "fall_count": 0,
  "publish_hz": 49.99947711711855,
  "debug_hz": 50.01226947850949,
  "realtime_factor": 1.000020609405834,
  "spring_disabled": true,
  "base_height_min_m": 0.786542841163305,
  "base_height_max_m": 0.7869530741778974,
  "actual_base_displacement_m": 0.00039224012213878083,
  "actual_base_path_length_m": 0.011950496229417898,
  "tracking_rmse_rad": 0.1110807496245436,
  "left_arm_tracking_rmse_rad": 0.19744028616035064,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.081991349650829e-08,
    "p95": 1.081991349650829e-08,
    "max": 1.2574590194215764e-08
  },
  "target_observation_lag_ms": {
    "p50": 1308.9840320000121,
    "p95": 1313.9323143000324,
    "max": 1314.796360999992
  },
  "max_reference_edit_rad": 0.4258596607506291,
  "left_shoulder_actual_range_rad": 0.0051534175872802734,
  "left_arm_reference_speed_max_rad_s": 0.6849769105641612,
  "left_arm_reference_accel_max_rad_s2": 8.000000000000004,
  "intervention_selected_speed_max_rad_s": 1.1362305919017102,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 0.6389209999611012,
    "p95": 2.1895977999861316,
    "max": 5.087191000029634
  },
  "physics_sample_gap_ms": {
    "p50": 20.01513899998031,
    "p95": 20.332219249993955,
    "max": 20.72984700004099
  },
  "feedback_sample_gap_ms": {
    "p50": 19.92526799998018,
    "p95": 25.024386750033045,
    "max": 33.07678000004444
  },
  "publish_interval_ms": {
    "p50": 20.000123499983147,
    "p95": 20.05223325002703,
    "max": 20.659802000011496
  },
  "scheduling_lateness_ms": {
    "p50": 0.07780000180446223,
    "p95": 0.1361546010855363,
    "max": 0.7372340021447599
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.849,
      "p95": 8.203449999999995,
      "max": 11.521
    },
    "policy": {
      "p50": 2.213,
      "p95": 11.702149999999996,
      "max": 13.777
    },
    "observation_to_motor": {
      "p50": 7.7615,
      "p95": 16.030099999999997,
      "max": 18.439
    }
  },
  "http_command_queue_ms": {
    "p50": 4.899773999966328,
    "p95": 17.475099700027386,
    "max": 18.61655899995185
  },
  "http_to_reference_publish_ms": {
    "p50": 7.158919000005426,
    "p95": 20.499148699980196,
    "max": 20.96504299998969
  },
  "takeover_seams": [
    {
      "t": 307.799776523,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1425.109375,
      "controller": 362.00390625,
      "publisher": 98.11328125,
      "viewer": 0
    },
    "max_sum_rss_mib": 1885.2265625,
    "min_wsl_available_mib": 4933.62890625,
    "nvml_gpu_peak_mib": 1209,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
