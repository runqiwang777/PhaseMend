# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_151255_interactive_bounded_248564",
  "active_seconds": 2.1001707019999856,
  "published_frames": 105,
  "debug_samples": 105,
  "physics_samples": 105,
  "fall_count": 0,
  "publish_hz": 49.99853759085146,
  "debug_hz": 50.03934511911594,
  "realtime_factor": 0.999948472367286,
  "spring_disabled": true,
  "base_height_min_m": 0.7872057481469205,
  "base_height_max_m": 0.7872348936585042,
  "actual_base_displacement_m": 0.00026507444932788725,
  "actual_base_path_length_m": 0.001266496590968102,
  "tracking_rmse_rad": 0.12399762535791624,
  "left_arm_tracking_rmse_rad": 0.23470101192639548,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 1.081991349650829e-08,
    "p95": 1.081991349650829e-08,
    "max": 1.081991349650829e-08
  },
  "target_observation_lag_ms": null,
  "max_reference_edit_rad": 0.0,
  "left_shoulder_actual_range_rad": 0.00034806132316589355,
  "left_arm_reference_speed_max_rad_s": 0.0,
  "left_arm_reference_accel_max_rad_s2": 0.0,
  "intervention_selected_speed_max_rad_s": 0,
  "intervention_selected_accel_max_rad_s2": 0,
  "edit_compute_ms": {
    "p50": 0.5509609999876375,
    "p95": 0.843251400010558,
    "max": 1.6896170000109123
  },
  "physics_sample_gap_ms": {
    "p50": 19.981845499998485,
    "p95": 20.43947859998525,
    "max": 22.162363000006735
  },
  "feedback_sample_gap_ms": {
    "p50": 20.027305500008197,
    "p95": 21.741513450004387,
    "max": 23.36407300001042
  },
  "publish_interval_ms": {
    "p50": 19.99860150000643,
    "p95": 20.05684964998693,
    "max": 20.1285690000077
  },
  "scheduling_lateness_ms": {
    "p50": 0.11644699912949363,
    "p95": 0.15995479945445368,
    "max": 0.22010499998259547
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.125,
      "p95": 4.73,
      "max": 4.754
    },
    "policy": {
      "p50": 1.574,
      "p95": 3.6502,
      "max": 3.799
    },
    "observation_to_motor": {
      "p50": 3.699,
      "p95": 8.273,
      "max": 8.309
    }
  },
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1422.921875,
      "controller": 360.7265625,
      "publisher": 107.57421875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1890.59765625,
    "min_wsl_available_mib": 4876.17578125,
    "nvml_gpu_peak_mib": 202,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
