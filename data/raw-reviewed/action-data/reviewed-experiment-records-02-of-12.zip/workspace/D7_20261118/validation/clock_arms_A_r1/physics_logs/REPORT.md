# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261118_235716_interactive_bounded_608521",
  "active_seconds": 16.640108491000007,
  "published_frames": 832,
  "debug_samples": 827,
  "physics_samples": 832,
  "fall_count": 0,
  "publish_hz": 49.99944864928078,
  "debug_hz": 49.70081555833053,
  "realtime_factor": 0.9999898593091219,
  "spring_disabled": true,
  "base_height_min_m": 0.7846477618419754,
  "base_height_max_m": 0.786547189806543,
  "actual_base_displacement_m": 0.004366065985571055,
  "actual_base_path_length_m": 0.11496737741264078,
  "tracking_rmse_rad": 0.11700752070181114,
  "left_arm_tracking_rmse_rad": 0.20619258768616308,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 8.079751081998257e-09,
    "p95": 1.081991349650829e-08,
    "max": 1.2961528369246122e-08
  },
  "target_observation_lag_ms": {
    "p50": 582.2392569999977,
    "p95": 590.5441660999998,
    "max": 620.695631000018
  },
  "max_reference_edit_rad": 0.6030914578921954,
  "left_shoulder_actual_range_rad": 0.09256801009178162,
  "left_arm_reference_speed_max_rad_s": 1.232006538941377,
  "left_arm_reference_accel_max_rad_s2": 8.000000000000021,
  "intervention_selected_speed_max_rad_s": 1.232006538941377,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 2.0136370000045645,
    "p95": 3.4682300499895287,
    "max": 7.286485999998149
  },
  "physics_sample_gap_ms": {
    "p50": 19.9981299999763,
    "p95": 20.661969500011423,
    "max": 25.003265999998803
  },
  "feedback_sample_gap_ms": {
    "p50": 20.003683500007696,
    "p95": 26.84491474999362,
    "max": 128.4749060000081
  },
  "publish_interval_ms": {
    "p50": 20.000214999981836,
    "p95": 20.0821175000101,
    "max": 22.995398000006162
  },
  "scheduling_lateness_ms": {
    "p50": 0.08589049564022844,
    "p95": 0.17062209498703845,
    "max": 3.0978689979690444
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.677,
      "p95": 5.0264,
      "max": 5.153
    },
    "policy": {
      "p50": 1.881,
      "p95": 3.8009999999999957,
      "max": 4.64
    },
    "observation_to_motor": {
      "p50": 4.571,
      "p95": 8.778799999999995,
      "max": 9.76
    }
  },
  "http_command_queue_ms": {
    "p50": 9.95479899998486,
    "p95": 17.42398029999492,
    "max": 20.421787000003633
  },
  "http_to_reference_publish_ms": {
    "p50": 12.65742600000408,
    "p95": 20.39988890001041,
    "max": 25.09340000000293
  },
  "takeover_seams": [
    {
      "t": 161.17414662,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.30078125,
      "controller": 360.50390625,
      "publisher": 107.25390625,
      "viewer": 0
    },
    "max_sum_rss_mib": 1888.87109375,
    "min_wsl_available_mib": 4876.5703125,
    "nvml_gpu_peak_mib": 1262,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
