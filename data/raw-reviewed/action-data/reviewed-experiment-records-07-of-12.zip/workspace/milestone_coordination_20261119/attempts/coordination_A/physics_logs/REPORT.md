# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_191920_interactive_bounded_813123",
  "active_seconds": 16.140130509000016,
  "published_frames": 807,
  "debug_samples": 804,
  "physics_samples": 807,
  "fall_count": 0,
  "publish_hz": 49.999717458172306,
  "debug_hz": 49.84387232861955,
  "realtime_factor": 0.9999816093337689,
  "spring_disabled": true,
  "base_height_min_m": 0.7704603378295616,
  "base_height_max_m": 0.7868298153441031,
  "actual_base_displacement_m": 0.0027911331280947357,
  "actual_base_path_length_m": 0.09977861476058271,
  "tracking_rmse_rad": 0.11120970341318599,
  "left_arm_tracking_rmse_rad": 0.1992495594247423,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 8.608495703397579e-09,
    "p95": 1.081991349650829e-08,
    "max": 1.310989330870885e-08
  },
  "target_observation_lag_ms": {
    "p50": 385.92030050000403,
    "p95": 392.63607490002244,
    "max": 410.04289099998914
  },
  "max_reference_edit_rad": 1.2753669448875065,
  "left_shoulder_actual_range_rad": 0.2819802463054657,
  "left_arm_reference_speed_max_rad_s": 0.8028220554293114,
  "left_arm_reference_accel_max_rad_s2": 8.000000000000023,
  "intervention_selected_speed_max_rad_s": 0.8989252042964524,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 1.9261749999941458,
    "p95": 2.293902799988245,
    "max": 4.874934999975267
  },
  "physics_sample_gap_ms": {
    "p50": 19.993518000006816,
    "p95": 20.41622649998942,
    "max": 24.142647000019224
  },
  "feedback_sample_gap_ms": {
    "p50": 20.009493999964434,
    "p95": 21.88724769998771,
    "max": 42.55232299999534
  },
  "publish_interval_ms": {
    "p50": 19.999303500014776,
    "p95": 20.06315724999297,
    "max": 21.491995999951996
  },
  "scheduling_lateness_ms": {
    "p50": 0.10063000325999383,
    "p95": 0.1583375041263934,
    "max": 1.5924580027899538
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.651,
      "p95": 3.952699999999999,
      "max": 5.606
    },
    "policy": {
      "p50": 1.816,
      "p95": 3.784499999999998,
      "max": 4.516
    },
    "observation_to_motor": {
      "p50": 4.526,
      "p95": 7.729499999999998,
      "max": 10.122
    }
  },
  "http_command_queue_ms": {
    "p50": 2.256829000032212,
    "p95": 3.6276379999549135,
    "max": 18.562524000003577
  },
  "http_to_reference_publish_ms": {
    "p50": 4.514114000016889,
    "p95": 6.673682999974062,
    "max": 21.349979999968127
  },
  "takeover_seams": [
    {
      "t": 383.505414934,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.265625,
      "controller": 363.484375,
      "publisher": 106.99609375,
      "viewer": 0
    },
    "max_sum_rss_mib": 1891.0546875,
    "min_wsl_available_mib": 4892.0,
    "nvml_gpu_peak_mib": 1150,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
