# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261118_235920_interactive_bounded_103029",
  "active_seconds": 16.56011939399997,
  "published_frames": 828,
  "debug_samples": 828,
  "physics_samples": 828,
  "fall_count": 0,
  "publish_hz": 49.99989438051329,
  "debug_hz": 50.03178311068174,
  "realtime_factor": 0.9999974955932412,
  "spring_disabled": true,
  "base_height_min_m": 0.7858276923340646,
  "base_height_max_m": 0.7872999037194346,
  "actual_base_displacement_m": 0.0035545392413989726,
  "actual_base_path_length_m": 0.09928358751226093,
  "tracking_rmse_rad": 0.11817454100171605,
  "left_arm_tracking_rmse_rad": 0.21600704282500077,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 8.059973090446086e-09,
    "p95": 1.081991349650829e-08,
    "max": 0.001040814462132896
  },
  "target_observation_lag_ms": {
    "p50": 353.8359794999906,
    "p95": 358.8029759500074,
    "max": 397.58821399999533
  },
  "max_reference_edit_rad": 0.5955184946302472,
  "left_shoulder_actual_range_rad": 0.09071417897939682,
  "left_arm_reference_speed_max_rad_s": 1.2694476765612417,
  "left_arm_reference_accel_max_rad_s2": 8.000000000000021,
  "intervention_selected_speed_max_rad_s": 1.2694476765612417,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 1.959898500018653,
    "p95": 3.028721749998908,
    "max": 6.095707999975275
  },
  "physics_sample_gap_ms": {
    "p50": 20.005973000024824,
    "p95": 20.346246199983398,
    "max": 23.29325600004495
  },
  "feedback_sample_gap_ms": {
    "p50": 20.234370000025592,
    "p95": 27.171765100001718,
    "max": 48.51498700003276
  },
  "publish_interval_ms": {
    "p50": 20.000181999989763,
    "p95": 20.136564299980364,
    "max": 23.56340899996212
  },
  "scheduling_lateness_ms": {
    "p50": 0.08417651255854253,
    "p95": 0.2320863104444015,
    "max": 3.649545010375732
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 2.6745,
      "p95": 5.75195,
      "max": 7.001
    },
    "policy": {
      "p50": 1.882,
      "p95": 4.4636,
      "max": 7.303
    },
    "observation_to_motor": {
      "p50": 4.5555,
      "p95": 10.06345,
      "max": 10.295
    }
  },
  "http_command_queue_ms": {
    "p50": 4.651372000012088,
    "p95": 17.70548219999455,
    "max": 19.534415999999055
  },
  "http_to_reference_publish_ms": {
    "p50": 7.1476719999736815,
    "p95": 20.166876799976304,
    "max": 24.481574999981603
  },
  "takeover_seams": [
    {
      "t": 281.639053629,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.6015625,
      "controller": 363.109375,
      "publisher": 107.421875,
      "viewer": 0
    },
    "max_sum_rss_mib": 1891.7890625,
    "min_wsl_available_mib": 4932.0,
    "nvml_gpu_peak_mib": 1251,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
