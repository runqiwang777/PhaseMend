CMU 13_30 motion source

This archive contains the 13.asf skeleton, 13_30.amc motion clip, and the local retargeted human_skeleton_candidate.npz used in the reviewed PhaseMend trials. The source files retain the accompanying LICENSE and provenance metadata.

CMU Graphics Lab requests this acknowledgment when publishing results: “The data used in this project was obtained from mocap.cs.cmu.edu. The database was created with funding from NSF EIA-0196217.” The CMU database terms permit research use and prohibit resale of the data, including converted forms.

Source: https://mocap.cs.cmu.edu/
