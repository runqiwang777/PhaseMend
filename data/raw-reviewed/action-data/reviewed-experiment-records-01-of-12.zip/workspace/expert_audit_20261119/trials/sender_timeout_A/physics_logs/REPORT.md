# 本次真实仿真运行

- 实验判定：通过
- 场景：interactive；方法：bounded
- 基线控制器：冻结的官方 SONIC，C++ TensorRT；物理：单 G1 MuJoCo。
- 操作者输入：已映射的合成关节流/本地控制面板；未验证真人捕捉或人体重定向。
- 编辑耗时不等于输入到实际关节响应延迟；周期日志中的策略耗时是抽样统计。
- target_observation_lag_ms 是动态且匹配明确的参考帧在反馈中出现的估计滞后；不含人体感知和机械响应。
- 关节限位和速度限制不构成动态平衡或碰撞可行性的保证。

```json
{
  "phase": "completed",
  "error": null,
  "run": "/home/wangrunqi/sonic_takeover_share_20261114/takeover/runs/20261119_094446_interactive_bounded_715232",
  "active_seconds": 20.180125247000007,
  "published_frames": 1009,
  "debug_samples": 1009,
  "physics_samples": 1009,
  "fall_count": 0,
  "publish_hz": 49.99986613875122,
  "debug_hz": 50.01091629896204,
  "realtime_factor": 1.0000216077590636,
  "spring_disabled": true,
  "base_height_min_m": 0.7850180396054978,
  "base_height_max_m": 0.787184827837261,
  "actual_base_displacement_m": 0.0017343787134602392,
  "actual_base_path_length_m": 0.20111933410417057,
  "tracking_rmse_rad": 0.16008537679034424,
  "left_arm_tracking_rmse_rad": 0.2329565518952856,
  "controller_target_to_published_nearest_rmse_rad": {
    "p50": 9.345857345059541e-09,
    "p95": 1.3163584323293262e-08,
    "max": 1.6549849097210422e-08
  },
  "target_observation_lag_ms": {
    "p50": 512.7004889999967,
    "p95": 518.0131068500074,
    "max": 551.9724819999965
  },
  "max_reference_edit_rad": 2.523263141705498,
  "left_shoulder_actual_range_rad": 0.2930688261985779,
  "left_arm_reference_speed_max_rad_s": 1.1213894339637154,
  "left_arm_reference_accel_max_rad_s2": 8.00000000000023,
  "intervention_selected_speed_max_rad_s": 1.5000000000000013,
  "intervention_selected_accel_max_rad_s2": 8.00000000000023,
  "edit_compute_ms": {
    "p50": 2.4219270000003235,
    "p95": 4.15590979999365,
    "max": 6.346261000004461
  },
  "physics_sample_gap_ms": {
    "p50": 19.993180499994878,
    "p95": 20.40705819999431,
    "max": 24.70634600001631
  },
  "feedback_sample_gap_ms": {
    "p50": 19.963437999990674,
    "p95": 23.474721500002715,
    "max": 50.13940699998898
  },
  "publish_interval_ms": {
    "p50": 20.000055999986444,
    "p95": 20.071600949995627,
    "max": 22.563254000004918
  },
  "scheduling_lateness_ms": {
    "p50": 0.09039999130777687,
    "p95": 0.16255199699344294,
    "max": 2.6507609911163854
  },
  "final_editor_state": "automatic",
  "controller_timing_sampled_ms": {
    "observation": {
      "p50": 3.288,
      "p95": 3.516,
      "max": 5.977
    },
    "policy": {
      "p50": 2.114,
      "p95": 2.2675,
      "max": 4.68
    },
    "observation_to_motor": {
      "p50": 5.387,
      "p95": 5.702999999999999,
      "max": 10.657
    }
  },
  "http_command_queue_ms": {
    "p50": 6.658323999999993,
    "p95": 17.464372899985392,
    "max": 19.246663000018316
  },
  "http_to_reference_publish_ms": {
    "p50": 10.36612400000081,
    "p95": 21.365788699998234,
    "max": 24.52028400000472
  },
  "takeover_seams": [
    {
      "t": 181.013143558,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    },
    {
      "t": 186.893120217,
      "reference_step_max_rad": 0.0,
      "edit_offset_step_max_rad": 0.0
    }
  ],
  "checks": {
    "no_runtime_error": true,
    "actual_controller_feedback": true,
    "spring_disabled": true,
    "no_fall": true,
    "initialization_no_fall": true,
    "spring_external_force_zero": true,
    "realtime": true,
    "publish_rate": true,
    "target_received": true,
    "intervention_speed_limit": true,
    "intervention_acceleration_limit": true
  },
  "verified": true,
  "resources": {
    "max_rss_mib": {
      "sim": 1423.703125,
      "controller": 363.59765625,
      "publisher": 99.03125,
      "viewer": 0
    },
    "max_sum_rss_mib": 1886.33203125,
    "min_wsl_available_mib": 4933.59375,
    "nvml_gpu_peak_mib": 1263,
    "caveat": "RSS sums may double count shared pages; WSL NVML is not exact total VRAM."
  }
}
```
